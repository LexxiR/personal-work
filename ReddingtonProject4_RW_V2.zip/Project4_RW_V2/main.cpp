/*
 * Lexxi Reddington 
 * Project 4: Readers and Writers
 * VERSION 2 (Favor the Writers)
 * Operating Systems, Spring 2020
 */
 
#include <iostream>
#include <pthread.h>
#include <ctime>
#include <unistd.h>

// Constants
const int NUM_READERS = 4;
const int NUM_WRITERS = 4;
const int n = 2;

// Shared variables
int shared_data{0};
int rc{0};
int wc{0};
int writers_waiting{0};
int readers_waiting{0};

// Mutexes and conditional variables
pthread_mutex_t readwrite_mutex;
pthread_mutex_t resource_mutex;
pthread_mutex_t output_mutex; // Added to fix output formatting
pthread_cond_t condread;
pthread_cond_t condwrite;

// Start routines
void *writer(void *arg);
void *reader(void *arg);

int main(int argc, char* argv[]) {    
    // Seed for random number generator
    std::srand(std::time(nullptr));
    
    // Initializations
    pthread_mutex_init(&readwrite_mutex, NULL);
    pthread_mutex_init(&resource_mutex, NULL);
    pthread_mutex_init(&output_mutex, NULL);
    pthread_cond_init(&condread, NULL);
    pthread_cond_init(&condwrite, NULL);    
    
    // NOTE: To better demonstrate the program's functionality,
    // half of the reader threads are created first, then 
    // half of the writer threads are created, and then the rest
    pthread_t rtid[NUM_READERS];
    int reader_thread_number[NUM_READERS];
    pthread_t wtid[NUM_WRITERS];
    int writer_thread_number[NUM_WRITERS];
    
    // Create the threads
    for (int i = 0; i < NUM_READERS / 2; ++i) {
        reader_thread_number[i] = i;
        int status = pthread_create(&rtid[i], NULL, reader, &reader_thread_number[i]);
        if (status != 0) {
            std::cerr << "Unable to create thread" << std::endl;
        }
    }
    
    for (int i = 0; i < NUM_WRITERS / 2; ++i) {
        writer_thread_number[i] = i;
        int status = pthread_create(&wtid[i], NULL, writer, &writer_thread_number[i]);
        if (status != 0) {
            std::cerr << "Unable to create thread" << std::endl;
        }
    }
    
    for (int i = NUM_READERS / 2; i < NUM_READERS; ++i) {
        reader_thread_number[i] = i;
        int status = pthread_create(&rtid[i], NULL, reader, &reader_thread_number[i]);
        if (status != 0) {
            std::cerr << "Unable to create thread" << std::endl;
        }
    }
    
    for (int i = NUM_WRITERS / 2; i < NUM_WRITERS; ++i) {
        writer_thread_number[i] = i;
        int status = pthread_create(&wtid[i], NULL, writer, &writer_thread_number[i]);
        if (status != 0) {
            std::cerr << "Unable to create thread" << std::endl;
        }
    }
    
    // Join the threads
    for (int i = 0; i < NUM_READERS; ++i) {
        pthread_join(rtid[i], NULL);
    }
    
    for (int i = 0; i < NUM_WRITERS; ++i) {
        pthread_join(wtid[i], NULL);
    }
    
    // Clean up
    pthread_mutex_destroy(&readwrite_mutex);
    pthread_mutex_destroy(&resource_mutex);
    pthread_mutex_destroy(&output_mutex);
    pthread_cond_destroy(&condread);
    pthread_cond_destroy(&condwrite);
    
	return 0;
}

// Start routine for writers
void *writer(void *arg) {
    int num = *static_cast<int *>(arg);
    
    for (int i = 0; i < n; ++i) {
        // Ensure mutual exclusion
        pthread_mutex_lock(&readwrite_mutex);
        // Account for the pending writer
        writers_waiting += 1;
        // Block pending writers if readers are already in Critical Region
        while (rc > 0) pthread_cond_wait(&condwrite, &readwrite_mutex);
        pthread_mutex_unlock(&readwrite_mutex);
        
        // Start: Critical Region
        usleep(rand()%90 + 10);
        // Ensure mutual exclusion
        pthread_mutex_lock(&resource_mutex);
        // There should only ever be 1 writer in the Critical Region at a time
        wc += 1; 
        // Perform write
        shared_data = std::rand();
        std::cout << "writer " << num << " wrote " << shared_data << " " << rc << " readers(s), " << readers_waiting << " reader(s) waiting, " << writers_waiting - 1 << " writer(s) waiting\n";
        wc -= 1;
        pthread_mutex_unlock(&resource_mutex);
        // End: Critical Region
        
        // Ensure mutual exclusion
        pthread_mutex_lock(&readwrite_mutex);
        // The waiting writer has finished
        writers_waiting -= 1;
        // Signal any other waiting writers
        if (writers_waiting > 0) pthread_cond_signal(&condwrite);
        // Enable readers if no writers are waiting
        else pthread_cond_broadcast(&condread);
        
        pthread_mutex_unlock(&readwrite_mutex);
    }
    pthread_exit(0);
}

// Start routine for readers
void *reader(void *arg) {
    int num = *static_cast<int *>(arg);

    for (int i = 0; i < n; ++i) {
        // Ensure mutual exclusion
        pthread_mutex_lock(&readwrite_mutex);
        // Account for the new reader
        readers_waiting += 1;
        // Sleep readers if a writer is waiting
        while(writers_waiting > 0) pthread_cond_wait(&condread, &readwrite_mutex);
        // The first reader should lock the resource before reading
        if (readers_waiting == 1) pthread_mutex_lock(&resource_mutex);        
        // Account for the reader in the Critical Region
        rc += 1;
        pthread_mutex_unlock(&readwrite_mutex);
        
        //Perform read
        usleep(rand()%90 + 10);
        pthread_mutex_lock(&output_mutex);
        std::cout << "reader " << num << " read " << shared_data << " " << rc << " reader(s), " << readers_waiting - 1 << " reader(s) waiting, " << writers_waiting << " writer(s) waiting\n";
        pthread_mutex_unlock(&output_mutex);

        // Ensure mutual exclusion 
        pthread_mutex_lock(&readwrite_mutex);
        // The reader has finished
        rc -= 1;
        readers_waiting -= 1;
        // Enable writers if there are no more readers in the Critical Region
        if (rc == 0) {
            pthread_mutex_unlock(&resource_mutex);
            pthread_cond_signal(&condwrite); // Wake up a waiting writer
        }
        pthread_mutex_unlock(&readwrite_mutex);
    }
    pthread_exit(0);
}
