/*
 * Lexxi Reddington 
 * Project 5: Scheduling Simulation
 * Operating Systems, Spring 2020
 */
 
#include "Process.h"
#include "RR_Scheduler.h"
 
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

int main(int argc, char* argv[]) {
	// Check the number of command line arguments provided
    if (argc != 4) {
        // Tell the user how to run the program
        std::cerr << "Usage: " << argv[0] << " <input filename> <block duration> <quantum>" << std::endl;
        return 1;
    }
    
    // Open input file
    std::ifstream in(argv[1]);
    if (!in.is_open()) {
        std::cerr << "Error: Couldn't open file." << std::endl;
        return 1;
    }
    
    // Read the input file
    std::string line;
    std::vector<Process> processes_list;
        
    while (std::getline(in, line)) {
        // Create a list of processes
        std::istringstream ss(line); 
        std::string process_name;
        int arrival_time;
        int total_time;
        int cpu_burst;
        do { 
            ss >> process_name; 
            ss >> arrival_time;
            ss >> total_time;
            ss >> cpu_burst;
        } while (ss);
        Process p(process_name, arrival_time, total_time, cpu_burst);
        processes_list.push_back(p);
    }
    in.close();
    
    // Create an object of type RR_Scheduler
    int block_duration = strtol(argv[2], NULL, 10);
    int quantum = strtol(argv[3], NULL, 10);
    RR_Scheduler sim(processes_list, block_duration, quantum);
    
    // Call the RR_Scheduler’s run method to start the simulation
    sim.run();
    
	return 0;
}
