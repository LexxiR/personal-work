/*
 * Lexxi Reddington 
 * Project 5: Scheduling Simulation
 * Operating Systems, Spring 2020
 */
 
#include "RR_Scheduler.h"
#include "Process.h"

#include <limits> 

// Constructor
RR_Scheduler::RR_Scheduler(std::vector<Process> i_processes_list, int i_block_duration, int i_quantum) : processes_list(i_processes_list), block_duration(i_block_duration), quantum(i_quantum), current_time(0) {
    // Add all processes to the arriving list
    for (Process p : processes_list) {
        arriving_list.push(p);
    }
    
    // Add any processes that arrive at time = 0 to the ready list
    while (arriving_list.front().get_arrival_time() == current_time) {
        ready_list.push(arriving_list.front());
        arriving_list.pop();
    }
}

// Round Robin Scheduler Simulation
void RR_Scheduler::run() {
    std::cout << block_duration << " " << quantum << "\n";
    
    std::string name = "";
    int interval = 0;
    std::string code = "";
    bool flag = false;
    
    int remaining = processes_list.size();
    while (remaining > 0) {
        // Check if there is a ready process
        if (ready_list.size() > 0) {
            // Get the first ready process
            Process p = ready_list.front();
            ready_list.pop();
            name = p.get_process_name();
            // The process still needs to run
            // Check if there is another process waiting
            if(gets_interrupted(current_time + p.get_remain_cpu_burst())) {
                // Another process will be coming in
                if (p.get_remain_cpu_burst() <= quantum) {
                    // Process blocks before quantum runs out, so run for remain_cpu_burst amount of time
                    interval = p.get_remain_cpu_burst();
                    code = "B";
                    p.set_total_time(p.get_total_time() - interval);
                    if (p.get_total_time() <= 0){
                        // The process has terminated
                        code = "T";
                        --remaining;
                        p.set_finish_time(current_time + interval);
                        terminated_list.push(p);
                    } else {
                        // The process has blocked for I/O
                        p.set_remain_cpu_burst(p.get_cpu_burst());
                        p.set_unblock_time(current_time + interval + block_duration);
                        waiting_list.push(p);
                    }
                } else {
                    // Quantum runs out first, so run for quantum amount of time
                    interval = quantum;
                    code = "Q";
                    p.set_total_time(p.get_total_time() - interval);
                    if (p.get_total_time() <= 0){
                        // The process has terminated
                        code = "T";
                        --remaining;
                        p.set_finish_time(current_time + interval);
                        terminated_list.push(p);
                    } else {
                        // The process has finished its quantum
                        p.set_remain_cpu_burst(p.get_remain_cpu_burst() - interval);
                        // Reset the remaining cpu burst amount for the next round
                        if (p.get_remain_cpu_burst() == 0) p.set_remain_cpu_burst(p.get_cpu_burst());
                        flag = true;
                    }
                }
            } else {
                // The process may run for its remaining cpu burst amount of time
                // because we know another process won't come in in the meantime 
                interval = p.get_remain_cpu_burst();
                code = "B";
                p.set_total_time(p.get_total_time() - interval);
                if (p.get_total_time() <= 0){
                    // The process has terminated
                    code = "T";
                    --remaining;
                    p.set_finish_time(current_time + interval);
                    terminated_list.push(p);
                } else {
                    // The process has blocked for I/O
                    p.set_remain_cpu_burst(p.get_cpu_burst());
                    p.set_unblock_time(current_time + interval + block_duration);
                    waiting_list.push(p);
                }
            }
            std::cout << current_time << "\t" << name << "\t" << interval << "\t" << code << "\n";

            // Add processes that have completed their I/O
            while (waiting_list.size() > 0 && waiting_list.front().get_unblock_time() <= current_time + interval) {
                ready_list.push(waiting_list.front());
                waiting_list.pop();
            }
            
            // Add arriving processes
            while (arriving_list.size() > 0 && arriving_list.front().get_arrival_time() <= current_time + interval) {
                ready_list.push(arriving_list.front());
                arriving_list.pop();
            }
            
            // Add processes that have finished their quantum
            if (flag) {
                ready_list.push(p);
                flag = false;
            }
        } else {
            // There is no ready process, so the CPU is idle
            name = "[IDLE]";
            code = "I";
            // Determine when the CPU will no longer be idle
            // This happens when a process arrives or is done waiting
            int atime = std::numeric_limits<int>::max();
            int wtime = std::numeric_limits<int>::max();
            if (arriving_list.size() > 0) atime = arriving_list.front().get_arrival_time();
            if (waiting_list.size() > 0) wtime = waiting_list.front().get_unblock_time();
            if (atime < wtime) interval = atime - current_time;
            else interval = wtime - current_time;            
            std::cout << current_time << "\t" << name << "\t" << interval << "\t" << code << "\n";
        
            // Add arriving processes
            while (arriving_list.size() > 0 && arriving_list.front().get_arrival_time() <= current_time + interval) {
                ready_list.push(arriving_list.front());
                arriving_list.pop();
            }
            
            // Add processes that have completed their I/O
            while (waiting_list.size() > 0 && waiting_list.front().get_unblock_time() <= current_time + interval) {
                ready_list.push(waiting_list.front());
                waiting_list.pop();
            }
        }    
        current_time += interval;
    }
    
    // Compute and print the turnaround times
    std::cout << current_time << "\t[END]\n";
    float avg_turnaround_time = 0;
    while (!terminated_list.empty()) {
        Process p = terminated_list.front();
        terminated_list.pop();
        std::cout << p.get_process_name() << "\t" << p.get_finish_time() - p.get_arrival_time() << "\n";
        avg_turnaround_time += (p.get_finish_time() - p.get_arrival_time());
    }
    // The average should have two digits to the right of the decimal point
    avg_turnaround_time /= processes_list.size();
    printf("%.2f\n", avg_turnaround_time);
}

// Helper function to determine if a new process will arrive before the current running one ends
bool RR_Scheduler::gets_interrupted(int finish_time) {
    // There is another ready process
    if (ready_list.size() > 0) return true;
    // A ready process will arrive before finish_time
    if (arriving_list.size() > 0 && arriving_list.front().get_arrival_time() <= finish_time) return true; 
    // A ready process will unblock before finish_time
    if (waiting_list.size() > 0 && waiting_list.front().get_unblock_time() <= finish_time) return true;
    return false;
}

// Destructor
RR_Scheduler::~RR_Scheduler() {}
