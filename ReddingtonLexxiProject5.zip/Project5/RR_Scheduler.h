/*
 * Lexxi Reddington 
 * Project 5: Scheduling Simulation
 * Operating Systems, Spring 2020
 */
 
#ifndef RR_SCHEDULER_H
#define RR_SCHEDULER_H

#include "Process.h"
#include <vector>
#include <queue>

class RR_Scheduler {
private:
    std::vector<Process> processes_list;
    int block_duration;
    int quantum;
    int current_time;
    
    // Queues to hold processes in a given state
    std::queue<Process> arriving_list;
    std::queue<Process> ready_list;
    std::queue<Process> waiting_list;
    std::queue<Process> terminated_list;
    
    // Private member helper function (to divide up work for run())
    bool gets_interrupted(int finish_time);
    
public:
    RR_Scheduler(std::vector<Process> i_processes_list, int i_block_duration, int i_quantum);
    ~RR_Scheduler();
    // The simulation method
    void run();
};
    
#endif // RR_SCHEDULER_H
