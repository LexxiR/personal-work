/*
 * Lexxi Reddington 
 * Project 5: Scheduling Simulation
 * Operating Systems, Spring 2020
 */
 
#ifndef PROCESS_H
#define PROCESS_H

#include <iostream>

class Process {
private:
    std::string process_name;
    int arrival_time;
    int total_time;
    int cpu_burst;
    int remain_cpu_burst;
    int unblock_time;
    int finish_time;
public:
    Process(std::string i_process_name, int i_arrival_time, int i_total_time, int i_cpu_burst);
    
    // Getters for private member variables
    std::string get_process_name() const;
    int get_arrival_time() const;
    int get_total_time() const;
    int get_cpu_burst() const;
    int get_remain_cpu_burst() const;
    int get_unblock_time() const;
    int get_finish_time() const;
    
    // Setters for private member variables
    void set_process_name(const std::string &i_process_name);
    void set_arrival_time(const int &i_arrival_time);
    void set_total_time(const int &i_total_time);
    void set_cpu_burst(const int &i_cpu_burst);
    void set_remain_cpu_burst(const int &i_remain_cpu_burst);
    void set_unblock_time(const int &i_unblock_time);
    void set_finish_time(const int &i_finish_time);
    ~Process();
};

#endif // PROCESS_H
