/*
 * Lexxi Reddington 
 * Project 5: Scheduling Simulation
 * Operating Systems, Spring 2020
 */
 
#include "Process.h"

// Constructor
Process::Process(std::string i_process_name, int i_arrival_time, int i_total_time, int i_cpu_burst) : process_name(i_process_name), arrival_time(i_arrival_time), total_time(i_total_time), cpu_burst(i_cpu_burst), remain_cpu_burst(cpu_burst), unblock_time(0), finish_time(0) {}

// Getters for private member variables
std::string Process::get_process_name() const {
    return process_name;
}

int Process::get_arrival_time() const {
    return arrival_time;
}

int Process::get_total_time() const {
    return total_time;
}

int Process::get_cpu_burst() const {
    return cpu_burst;
}

int Process::get_remain_cpu_burst() const {
    return remain_cpu_burst;
}

int Process::get_unblock_time() const {
    return unblock_time;
}

int Process::get_finish_time() const {
    return finish_time;
}

// Setters for private member variables
void Process::set_process_name(const std::string &i_process_name) {
    process_name = i_process_name;
}

void Process::set_arrival_time(const int &i_arrival_time) {
    arrival_time = i_arrival_time;
}

void Process::set_total_time(const int &i_total_time) {
    total_time = i_total_time;
}

void Process::set_cpu_burst(const int &i_cpu_burst) {
    cpu_burst = i_cpu_burst;
}

void Process::set_remain_cpu_burst(const int &i_remain_cpu_burst) {
    remain_cpu_burst = i_remain_cpu_burst;
} 

void Process::set_unblock_time(const int &i_unblock_time) {
    unblock_time = i_unblock_time;
}

void Process::set_finish_time(const int &i_finish_time) {
    finish_time = i_finish_time;
}

// Destructor 
Process::~Process() {}
