/*
 * Lexxi Reddington 
 * Project 8: Paging
 * Operating Systems, Spring 2020
 */
 
#include "PageTableEntry.h"

PageTableEntry::PageTableEntry(uint32_t num_bits) : page_table_entry(0), num_bits(num_bits), last_added(false) {}

PageTableEntry::~PageTableEntry() {}

// Accessors
bool PageTableEntry::get_R() {
    std::bitset<32> bits(page_table_entry);
    return bits[31];
}

bool PageTableEntry::get_M() {
    std::bitset<32> bits(page_table_entry);
    return bits[30];
}

bool PageTableEntry::get_P() {
    std::bitset<32> bits(page_table_entry);
    return bits[29];
}

bool PageTableEntry::get_last_added() {
    return last_added;
}

uint32_t PageTableEntry::get_frame_number() {
    std::bitset<32> page_table_entry_bits(page_table_entry);
    std::bitset<32> comp = 3;
    std::bitset<32> frame = page_table_entry_bits & comp;
    uint32_t frame_number = frame.to_ulong();
    return frame_number;
}

// Mutators
void PageTableEntry::set_frame_number(uint32_t number) {
    std::bitset<32> number_in_bits(number);
    std::bitset<32> table_entry(page_table_entry);
    table_entry = number_in_bits | table_entry;
    page_table_entry = table_entry.to_ulong();
}

void PageTableEntry::reset() {
    std::bitset<32> pte(page_table_entry);
    pte[0] = false;
    pte[1] = false;
    page_table_entry = pte.to_ulong();
}

void PageTableEntry::set_R(bool b) {
    std::bitset<32> bits(page_table_entry);
    bits[31] = b;
    page_table_entry = bits.to_ulong();
}

void PageTableEntry::set_M(bool b) {
    std::bitset<32> bits(page_table_entry);
    bits[30] = b;
    page_table_entry = bits.to_ulong();
}

void PageTableEntry::set_P(bool b) {
    std::bitset<32> bits(page_table_entry);
    bits[29] = b;
    page_table_entry = bits.to_ulong();
}

void PageTableEntry::set_last_added(bool setter) {
    last_added = setter;
}