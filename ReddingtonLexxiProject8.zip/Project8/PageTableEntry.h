/*
 * Lexxi Reddington 
 * Project 8: Paging
 * Operating Systems, Spring 2020
 */
 
#ifndef PAGETABLEENTRY_H
#define PAGETABLEENTRY_H

#include <iostream>
#include <cstdint>
#include <bitset>

class PageTableEntry {
private: 
    uint32_t page_table_entry;
    uint32_t num_bits;
    bool last_added;
public:
    PageTableEntry(uint32_t num_bits);
    ~PageTableEntry();
    // Accessors
    bool get_R();
    bool get_M();
    bool get_P();
    uint32_t get_frame_number();
    bool get_last_added();
    // Mutators
    void set_R(bool b);
    void set_M(bool b);
    void set_P(bool b);
    void set_frame_number(uint32_t number);
    void set_last_added(bool setter);
    void reset();
};

#endif // PAGETABLEENTRY_H
