/*
 * Lexxi Reddington 
 * Project 8: Paging
 * Operating Systems, Spring 2020
 */
 
#include "Counter.h"

Counter::Counter() : counter_value(0), set(false) {}

Counter::~Counter() {}

// Helper function to perform the shifting and adding the R bit to the left
void Counter::modify_counter(bool R) {
    // First, the counters are each shifted right 1 bit before the R bit is added in. 
    std::bitset<8> bits(counter_value);
    bits >>= 1;
    // Second, the R bit is added to the leftmost rather than the rightmost bit.
    bits[7] = R;
    counter_value = bits.to_ulong();
}

// Other accessor and mutator functions
uint8_t Counter::get_counter_value() {
    return counter_value;
}

void Counter::set_counter_value(uint8_t val) {
    counter_value = val;
}

bool Counter::get_set() {
    return set;
}

void Counter::set_set(bool b) {
    set = b;
}

void Counter::reset() {
    counter_value = 0;
}