/*
 * Lexxi Reddington 
 * Project 8: Paging
 * Operating Systems, Spring 2020
 */
 
#include "PagingSimulator.h"

// Constructor to read the input file
PagingSimulator::PagingSimulator(std::string input_file) {
    // Open input file
    std::ifstream in(input_file);
    if (!in.is_open()) {
        std::cerr << "Error: Couldn't open file." << std::endl;
    } else {
        // Read the input file
        std::string line;
        while (std::getline(in, line)) {
            file.push_back(line);
        }
    }
}

PagingSimulator::~PagingSimulator() {}

// Simulation function
void PagingSimulator::run() {
    // Read in line 0 of the file
    std::istringstream ss(file[0]);
    int num_virtual_pages;
    ss >> num_virtual_pages;
    int num_phys_page_frames;
    ss >> num_phys_page_frames;
    int page_size;
    ss >> page_size;
    
    // Read in line 1 of the file
    std::istringstream ss1(file[1]);
    int num_processes;
    ss1 >> num_processes;
    
    if (num_processes < 2) {
        // Initial Output
        std::cout << "INITIAL TABLE SETUP:\n";
        std::cout << "Virtual Memory Size: " << page_size * num_virtual_pages << "\n";
        std::cout << "Physical Memory Size: " << page_size * num_phys_page_frames << "\n";
        std::cout << "Page Size: " << page_size << "\n";
        std::cout << "Number of Processes: " << num_processes << "\n";
        std::cout << "Number of Pages: " << num_virtual_pages << "\n";
        std::cout << "Number of Frames: " << num_phys_page_frames << "\n";
        std::cout << "Page Tables (with aging status)\n";
        
        // Create the processes    
        Process p(num_virtual_pages, num_phys_page_frames);
        
        // Print the initial table
        print_page_table(p);
        
        int frames_occupied = 0; // 0 - num_phys_page_frames
        bool alternate = false;
        
        // Save old page table (for updating ages)
        p.set_saved_page_table(p.get_page_table());
            
        for (uint i = 2; i < file.size(); ++i) {
            // Get the request for each line in the file
            std::istringstream line(file[i]);
            uint32_t process_number;
            line >> process_number;
            char read_write;
            line >> read_write;
            uint32_t memory_request;
            line >> memory_request;
            
            // Show initial request
            std::cout << "\nProcess " << process_number << " requests " << read_write << " " << memory_request << "\n";
            
            // Determine the page number
            uint32_t page_number = memory_request / page_size;
            std::cout << "Page number: " << page_number << "\n";
            
            // Check for a page fault, evict page if necessary
            std::vector<PageTableEntry> pg_tab = p.get_page_table();
            PageTableEntry specific_entry = pg_tab[page_number];
            
            p.set_last_added_value(page_number, true);
            
            uint32_t frame;
            if (frames_occupied < num_phys_page_frames) {
                // The page can be loaded without eviction, a page fault occurs
                frame = frames_occupied;
                std::cout << "Page fault ..." << std::endl;
                p.set_page_table_P(page_number, true);
                p.update_entry(page_number, frame);
                std::cout << "Loading page " << page_number << " of process " << process_number << " into frame " << frame << "\n";

                if (read_write == 'r') {
                    // Set R bit to 1 (page has been referenced)
                    p.set_page_table_R(page_number, true);
                }
                
                if (read_write == 'w') {
                    // Set W bit to 1 (page has been modified)
                    p.set_page_table_M(page_number, true);
                }
            } else {
                if (specific_entry.get_P()) {
                    // P is 1 so page is already in use (no eviction)
                    // Just update age with M bit
                    // No need to "load" the page, it's already there
                    frame = specific_entry.get_frame_number();
                    --frames_occupied;
                    if (read_write == 'r') {
                        // Set R bit to 1 (page has been referenced)
                        p.set_page_table_R(page_number, true);
                    }
                    if (read_write == 'w') {
                        // Set W bit to 1 (page has been modified)
                        p.set_page_table_M(page_number, true);
                    }
                } else {
                    // P is 0 so a page fault has occurred
                    std::cout << "Page fault ..." << std::endl;
                    // Aging Algorithm
                    // Determine the highest age
                    uint32_t position = page_to_evict(p);
                    frame = p.update_entry_P(position, false);
                    p.set_page_table_P(page_number, true);
                    p.update_entry_R(page_number, true);
                    p.update_entry(page_number, position);
                    frame = position;
                    std::cout << "Evicting process " << process_number << " page " << position << "\n";
                    --frames_occupied;
                    // Check if the page has been modified
                    if (pg_tab[position].get_M()) {
                        frame = pg_tab[position].get_frame_number();
                        std::cout << "Writing frame " << frame << " back to disk:\n";
                        // The page can be loaded without eviction, a page fault occurs
                        p.set_page_table_P(page_number, true);
                        p.reset(page_number);
                        p.update_entry(page_number, frame);                    
                        std::cout << "Loading page " << page_number << " of process " << process_number << " into frame " << frame << "\n";
                        if (read_write == 'r') {
                            // Set R bit to 1 (page has been referenced)
                            p.set_page_table_R(page_number, true);
                        }
                        if (read_write == 'w') {
                            // Set W bit to 1 (page has been modified)
                            p.set_page_table_M(page_number, true);
                        }
                        // Update age to all 0s
                        p.set_counter(page_number);
                        // Set the M bit back for the evicted page
                        p.set_page_table_M(position, false);
                    } else {
                        std::cout << "Loading page " << page_number << " of process " << process_number << " into frame " << position << "\n";
                        // Set the M bit back for the evicted page
                        p.set_page_table_M(position, false);
                        p.set_page_table_R(page_number, true);
                        if (read_write == 'w') {
                            // Set W bit to 1 (page has been modified)
                            p.set_page_table_M(page_number, true);
                        }
                    }
                }
            }
            std::cout << "Frame number: " << frame << "\n";
            
            // Calculate physical address
            uint32_t offset = memory_request % page_size;
            uint32_t phys_add = (frame * page_size) + offset;
            std::cout << "Physical address: " << phys_add << "\n";
            
            // Age the counters every two instructions
            if (i == file.size() - 1) {
                p.set_page_table_R(page_number, false);
                std::bitset<8> bitval(std::string("00000000"));
                p.replace(page_number, bitval.to_ulong());
            }
            if (alternate) p.age_counters();
            
            // Print the page table
            std::cout << "Page Tables (with aging status)\n";
            print_page_table(p);
            
            // Save old page table (for updating ages)
            p.set_saved_page_table(p.get_page_table());
            
            // Resets for next iteration
            p.set_page_table_R(page_number, false);
            alternate = !alternate;
            ++frames_occupied;
            p.set_last_added_value(page_number, false);
        }
    } else {
        run_helper(num_virtual_pages, num_phys_page_frames, page_size, num_processes);
    }
}

void PagingSimulator::run_helper(int num_virtual_pages, int num_phys_page_frames, int page_size, int num_processes) {
    // Initial Output
    std::cout << "INITIAL TABLE SETUP:\n";
    std::cout << "Virtual Memory Size: " << page_size * num_virtual_pages << "\n";
    std::cout << "Physical Memory Size: " << page_size * num_phys_page_frames << "\n";
    std::cout << "Page Size: " << page_size << "\n";
    std::cout << "Number of Processes: " << num_processes << "\n";
    std::cout << "Number of Pages: " << num_virtual_pages << "\n";
    std::cout << "Number of Frames: " << num_phys_page_frames << "\n";
    std::cout << "Page Tables (with aging status)\n";
    
    // Create the processes    
    Process p(num_virtual_pages, num_phys_page_frames);
    Process p1(num_virtual_pages, num_phys_page_frames);
    
    // Print the initial table
    print_page_table(p);
    print_page_table1(p1);
    
    int frames_occupied = 0; // 0 - num_phys_page_frames
    bool alternate = false;
    
    // Save old page table (for updating ages)
    p.set_saved_page_table(p.get_page_table());
    p1.set_saved_page_table(p1.get_page_table());
  
    for (uint i = 2; i < file.size(); ++i) {
        // Get the request for each line in the file
        std::istringstream line(file[i]);
        uint32_t process_number;
        line >> process_number;
        char read_write;
        line >> read_write;
        uint32_t memory_request;
        line >> memory_request;
        if (process_number == 0) {
            // Show initial request
            std::cout << "\nProcess " << process_number << " requests " << read_write << " " << memory_request << "\n";
            
            // Determine the page number
            uint32_t page_number = memory_request / page_size;
            std::cout << "Page number: " << page_number << "\n";
            
            // Check for a page fault, evict page if necessary
            std::vector<PageTableEntry> pg_tab = p.get_page_table();
            PageTableEntry specific_entry = pg_tab[page_number];
            p.set_last_added_value(page_number, true);
            
            uint32_t frame;
            if (frames_occupied < num_phys_page_frames) {
                // The page can be loaded without eviction, a page fault occurs
                frame = frames_occupied;
                std::cout << "Page fault ..." << std::endl;
                p.set_page_table_P(page_number, true);
                p.update_entry(page_number, frame);
                std::cout << "Loading page " << page_number << " of process " << process_number << " into frame " << frame << "\n";

                if (read_write == 'r') {
                    // Set R bit to 1 (page has been referenced)
                    p.set_page_table_R(page_number, true);
                }
                
                if (read_write == 'w') {
                    // Set W bit to 1 (page has been modified)
                    p.set_page_table_M(page_number, true);
                }
            } else {
                if (specific_entry.get_P()) {
                    // P is 1 so page is already in use (no eviction)
                    // Just update age with M bit
                    // No need to "load" the page, it's already there
                    frame = specific_entry.get_frame_number();
                    --frames_occupied;
                    if (read_write == 'r') {
                        // Set R bit to 1 (page has been referenced)
                        p.set_page_table_R(page_number, true);
                    }
                    if (read_write == 'w') {
                        // Set W bit to 1 (page has been modified)
                        p.set_page_table_M(page_number, true);
                    }
                } else {
                    // P is 0 so a page fault has occurred
                    std::cout << "Page fault ..." << std::endl;
                    // Aging Algorithm
                    // Determine the highest age
                    uint32_t position = page_to_evict(p);
                    frame = p.update_entry_P(position, false);
                    p.set_page_table_P(page_number, true);
                    p.update_entry_R(page_number, true);
                    p.update_entry(page_number, position);
                    frame = position;
                    std::cout << "Evicting process " << process_number << " page " << position << "\n";
                    --frames_occupied;
                    // Check if the page has been modified
                    if (pg_tab[position].get_M()) {
                        frame = pg_tab[position].get_frame_number();
                        std::cout << "Writing frame " << frame << " back to disk:\n";
                        // The page can be loaded without eviction, a page fault occurs
                        p.set_page_table_P(page_number, true);
                        p.reset(page_number);
                        p.update_entry(page_number, frame);                    
                        std::cout << "Loading page " << page_number << " of process " << process_number << " into frame " << frame << "\n";
                        if (read_write == 'r') {
                            // Set R bit to 1 (page has been referenced)
                            p.set_page_table_R(page_number, true);
                        }
                        if (read_write == 'w') {
                            // Set W bit to 1 (page has been modified)
                            p.set_page_table_M(page_number, true);
                        }
                        // Update age to all 0s
                        p.set_counter(page_number);
                        // Set the M bit back for the evicted page
                        p.set_page_table_M(position, false);
                    } else {
                        std::cout << "Loading page " << page_number << " of process " << process_number << " into frame " << position << "\n";
                        // Set the M bit back for the evicted page
                        p.set_page_table_M(position, false);
                        p.set_page_table_R(page_number, true);
                        if (read_write == 'w') {
                            // Set W bit to 1 (page has been modified)
                            p.set_page_table_M(page_number, true);
                        }
                    }
                }
            }
            std::cout << "Frame number: " << frame << "\n";
            
            // Calculate physical address
            uint32_t offset = memory_request % page_size;
            uint32_t phys_add = (frame * page_size) + offset;
            std::cout << "Physical address: " << phys_add << "\n";
            
            // Age the counters every two instructions
            if (i == file.size() - 1) {
                p.set_page_table_R(page_number, false);
                std::bitset<8> bitval(std::string("00000000"));
                p.replace(page_number, bitval.to_ulong());
            }
            if (alternate) p.age_counters();
            // Print the page table
            std::cout << "Page Tables (with aging status)\n";
            print_page_table(p);
            print_page_table1(p1);
            
            // Save old page table (for updating ages)
            p.set_saved_page_table(p.get_page_table());
            
            // Resets for next iteration
            p.set_page_table_R(page_number, false);
            alternate = !alternate;
            ++frames_occupied;
            p.set_last_added_value(page_number, false);
        } else {
            // Show initial request
            std::cout << "\nProcess " << process_number << " requests " << read_write << " " << memory_request << "\n";
            
            // Determine the page number
            uint32_t page_number = memory_request / page_size;
            std::cout << "Page number: " << page_number << "\n";
            
            // Check for a page fault, evict page if necessary
            std::vector<PageTableEntry> pg_tab = p1.get_page_table();
            PageTableEntry specific_entry = pg_tab[page_number];
            p1.set_last_added_value(page_number, true);
            
            uint32_t frame;
            if (frames_occupied < num_phys_page_frames) {
                // The page can be loaded without eviction, a page fault occurs
                frame = frames_occupied;
                std::cout << "Page fault ..." << std::endl;
                p1.set_page_table_P(page_number, true);
                p1.update_entry(page_number, frame);
                std::cout << "Loading page " << page_number << " of process " << process_number << " into frame " << frame << "\n";

                if (read_write == 'r') {
                    // Set R bit to 1 (page has been referenced)
                    p1.set_page_table_R(page_number, true);
                }
                
                if (read_write == 'w') {
                    // Set W bit to 1 (page has been modified)
                    p1.set_page_table_M(page_number, true);
                }
            } else {
                if (specific_entry.get_P()) {
                    // P is 1 so page is already in use (no eviction)
                    // Just update age with M bit
                    // No need to "load" the page, it's already there
                    frame = specific_entry.get_frame_number();
                    --frames_occupied;
                    if (read_write == 'r') {
                        // Set R bit to 1 (page has been referenced)
                        p1.set_page_table_R(page_number, true);
                    }
                    if (read_write == 'w') {
                        // Set W bit to 1 (page has been modified)
                        p1.set_page_table_M(page_number, true);
                    }
                } else {
                    // P is 0 so a page fault has occurred
                    std::cout << "Page fault ..." << std::endl;
                    // Aging Algorithm
                    // Determine the highest age
                    uint32_t position = page_to_evict(p1);
                    frame = p1.update_entry_P(position, false);
                    p1.set_page_table_P(page_number, true);
                    p1.update_entry_R(page_number, true);
                    p1.update_entry(page_number, position);
                    frame = position;
                    std::cout << "Evicting process " << process_number << " page " << position << "\n";
                    --frames_occupied;
                    // Check if the page has been modified
                    if (pg_tab[position].get_M()) {
                        frame = pg_tab[position].get_frame_number();
                        std::cout << "Writing frame " << frame << " back to disk:\n";
                        // The page can be loaded without eviction, a page fault occurs
                        p1.set_page_table_P(page_number, true);
                        p1.reset(page_number);
                        p1.update_entry(page_number, frame);                    
                        std::cout << "Loading page " << page_number << " of process " << process_number << " into frame " << frame << "\n";
                        if (read_write == 'r') {
                            // Set R bit to 1 (page has been referenced)
                            p1.set_page_table_R(page_number, true);
                        }
                        if (read_write == 'w') {
                            // Set W bit to 1 (page has been modified)
                            p1.set_page_table_M(page_number, true);
                        }
                        // Update age to all 0s
                        p1.set_counter(page_number);
                        // Set the M bit back for the evicted page
                        p1.set_page_table_M(position, false);
                    } else {
                        std::cout << "Loading page " << page_number << " of process " << process_number << " into frame " << position << "\n";
                        // Set the M bit back for the evicted page
                        p1.set_page_table_M(position, false);
                        p1.set_page_table_R(page_number, true);
                        if (read_write == 'w') {
                            // Set W bit to 1 (page has been modified)
                            p1.set_page_table_M(page_number, true);
                        }
                    }
                }
            }
            std::cout << "Frame number: " << frame << "\n";
            
            // Calculate physical address
            uint32_t offset = memory_request % page_size;
            uint32_t phys_add = (frame * page_size) + offset;
            std::cout << "Physical address: " << phys_add << "\n";
            
            // Age the counters every two instructions
            if (i == file.size() - 1) {
                p1.set_page_table_R(page_number, false);
                std::bitset<8> bitval(std::string("00000000"));
                p1.replace(page_number, bitval.to_ulong());
            }
            if (alternate) p1.age_counters();
            // Print the page table
            std::cout << "Page Tables (with aging status)\n";
            print_page_table(p);
            print_page_table1(p1);
        
            // Save old page table (for updating ages)
            p1.set_saved_page_table(p1.get_page_table());
        
            // Resets for next iteration
            alternate = !alternate;
            ++frames_occupied;        
            p1.set_page_table_R(page_number, false);
            p1.set_last_added_value(page_number, false);
        }
    }
}


void PagingSimulator::print_page_table(Process p) {
    std::cout << "Process 0" << "\n";
    std::cout << std::setw(8) << std::left << "page#" << std::setw(8) << "R" << std::setw(8) << "M" << std::setw(8) << "P" << std::setw(8) << "frame#" << std::setw(8) << "aging" << std::endl;
    int i = 0;
    std::vector<Counter> counters_set = p.get_counters();
    for (PageTableEntry pte : p.get_page_table()) {
        std::cout << std::setw(8) << std::left << i << std::setw(8) << pte.get_R() << std::setw(8) << pte.get_M() << std::setw(8) << pte.get_P() << std::setw(8) << pte.get_frame_number();
        if (pte.get_P()) {
            // P bit is 1, so show aging
            std::bitset<8> counter_set_bits(counters_set[i].get_counter_value());
            std::cout << std::setw(10) << counter_set_bits.to_string() << std::endl;
        } else {
            std::cout << std::endl;
        }
        ++i;
    }
}

void PagingSimulator::print_page_table1(Process p) {
    std::cout << "Process 1" << "\n";
    std::cout << std::setw(8) << std::left << "page#" << std::setw(8) << "R" << std::setw(8) << "M" << std::setw(8) << "P" << std::setw(8) << "frame#" << std::setw(8) << "aging" << std::endl;
    int i = 0;
    std::vector<Counter> counters_set = p.get_counters();
    for (PageTableEntry pte : p.get_page_table()) {
        std::cout << std::setw(8) << std::left << i << std::setw(8) << pte.get_R() << std::setw(8) << pte.get_M() << std::setw(8) << pte.get_P() << std::setw(8) << pte.get_frame_number();
        if (pte.get_P()) {
            // P bit is 1, so show aging
            std::bitset<8> counter_set_bits(counters_set[i].get_counter_value());
            std::cout << std::setw(10) << counter_set_bits.to_string() << std::endl;
        } else {
            std::cout << std::endl;
        }
        ++i;
    }
}

uint32_t PagingSimulator::page_to_evict(Process p) {
    std::vector<PageTableEntry> tab = p.get_page_table();
    // Search for the highest age
    uint32_t ct = 0xFFFFFFFF;
    uint32_t position = 0;
    uint32_t saved_position = position;
    std::vector<Counter> ct_set = p.get_counters();
    for (uint32_t i = 0; i < ct_set.size(); ++i) {
        if (ct_set[i].get_counter_value() < ct && tab[i].get_P()) {
            ct = ct_set[i].get_counter_value();
            std::bitset<8> bbb(ct);
            saved_position = i;
        }
    }
    return saved_position;
}
