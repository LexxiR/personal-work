/*
 * Lexxi Reddington 
 * Project 8: Paging
 * Operating Systems, Spring 2020
 */
 
#ifndef COUNTER_H
#define COUNTER_H

#include <stdint.h>
#include <bitset>
#include <iostream>

class Counter {
private:
    uint8_t counter_value;
    bool set;
public:
    Counter();
    ~Counter();
    // Member functions to access and update the counters
    void modify_counter(bool R);
    uint8_t get_counter_value();
    void set_counter_value(uint8_t);
    bool get_set();
    void set_set(bool b);
    void reset();
};

#endif // COUNTER_H
