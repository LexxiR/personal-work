/*
 * Lexxi Reddington 
 * Project 8: Paging
 * Operating Systems, Spring 2020
 */
 
#ifndef PAGINGSIMULATOR_H
#define PAGINGSIMULATOR_H

#include "Process.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cstdint>
#include <iomanip>
#include <bitset>

class PagingSimulator {
    friend class Process;
private:
    std::vector<std::string> file;
    void print_page_table(Process p);
    void print_page_table1(Process p);
    uint32_t page_to_evict(Process p);
    void run_helper(int num_virtual_pages, int num_phys_page_frames, int page_size, int num_processes);
public:
    PagingSimulator(std::string input_file);
    ~PagingSimulator();
    void run();
};

#endif // PAGINGSIMULATOR_H
