/*
 * Lexxi Reddington 
 * Project 8: Paging
 * Operating Systems, Spring 2020
 */

#include "PagingSimulator.h"

#include <iostream>

int main(int argc, char* argv[]) {
	// Check to see if the correct number of command line arguments is given
    if (argc != 2) {
        // Tell the user how to run the program
        std::cerr << "Usage: " << argv[0] << " <input filename>" << std::endl;
        return 1;
    }
    // Create an object of type PagingSimulator
    PagingSimulator sim(argv[1]);
    // Call the PagingSimulator’s run method to start the simulation
    sim.run();
	return 0;
}
