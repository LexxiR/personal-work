/*
 * Lexxi Reddington 
 * Project 8: Paging
 * Operating Systems, Spring 2020
 */
 
#include "Process.h"

Process::Process(uint32_t num_pages, uint32_t num_page_frames) : num_pages(num_pages), num_page_frames(num_page_frames) {
    uint32_t num_bits = log2(num_page_frames);
    for (uint32_t i = 0; i < num_pages; ++i) {
        PageTableEntry pte(num_bits);
        page_table.push_back(pte);
        Counter c;
        set_of_counters.push_back(c);
    }
}

Process::~Process() {}

// Accessors
uint32_t Process::get_num_pages() {
    return num_pages;
}

std::vector<PageTableEntry> Process::get_page_table() {
    return page_table;
}

std::vector<Counter> Process::get_counters() {
    return set_of_counters;
}

bool Process::get_last_added_value(uint32_t page_num) {
    PageTableEntry pte = page_table[page_num];
    return pte.get_last_added();
}

// Mutators 
void Process::set_page_table_R(uint32_t location_in_vector, bool b) {
    PageTableEntry pte = page_table[location_in_vector];
    pte.set_R(b);
    page_table[location_in_vector] = pte;
}

void Process::set_page_table_M(uint32_t location_in_vector, bool b) {
    PageTableEntry pte = page_table[location_in_vector];
    pte.set_M(b);
    page_table[location_in_vector] = pte;
}

void Process::set_page_table_P(uint32_t location_in_vector, bool b) {
    PageTableEntry pte = page_table[location_in_vector];
    pte.set_P(b);
    page_table[location_in_vector] = pte;
}

void Process::set_counter_set(uint32_t location_in_vector, bool b) {
    Counter c = set_of_counters[location_in_vector];
    c.set_set(b);
    set_of_counters[location_in_vector] = c;
}

void Process::update_entry(uint32_t location_in_vector, uint32_t frame) {
    PageTableEntry pte = page_table[location_in_vector];
    pte.set_frame_number(frame);
    page_table[location_in_vector] = pte;
}

uint32_t Process::update_entry_P(uint32_t location_in_vector, bool P) {
    PageTableEntry pte = page_table[location_in_vector];
    pte.set_P(P);
    page_table[location_in_vector] = pte;
    uint32_t ret = pte.get_frame_number();
    return ret;
}

void Process::update_entry_R(uint32_t location_in_vector, bool R) {
    PageTableEntry pte = page_table[location_in_vector];
    pte.set_R(R);
    page_table[location_in_vector] = pte;
}

void Process::set_last_added_value(uint32_t page_num, bool setter) {
    PageTableEntry pte = page_table[page_num];
    pte.set_last_added(setter);
    page_table[page_num] = pte;
}
    
void Process::set_saved_page_table(std::vector<PageTableEntry> pg_tab) {
    saved_page_table.clear();    
    for (int i = 0; i < pg_tab.size(); ++i) {
        saved_page_table.push_back(pg_tab[i]);
    }
}

void Process::modify_age_for_preloads(uint32_t location_in_vector) {
    Counter c = set_of_counters[location_in_vector];
    c.modify_counter(true);
    set_of_counters[location_in_vector] = c;
}

void Process::set_counter(uint32_t location_in_vector) {
    Counter c = set_of_counters[location_in_vector];
    c.reset();
    set_of_counters[location_in_vector] = c;
}

void Process::reset(uint32_t location_in_vector) {
    PageTableEntry pte = page_table[location_in_vector];
    pte.reset();
    page_table[location_in_vector] = pte;
}

void Process::replace(uint32_t location_in_vector, uint8_t val) {
    Counter c = set_of_counters[location_in_vector];
    c.set_counter_value(val);
    set_of_counters[location_in_vector] = c;
}

// Function to age the counters (based on the Aging Algorithm)
void Process::age_counters() {
    for (uint32_t i = 0; i < set_of_counters.size(); ++i) {
        Counter c = set_of_counters[i];
        PageTableEntry pte = page_table[i];
        if (pte.get_last_added() == 1) {
            c.modify_counter(true);
            set_of_counters[i] = c;
        } else {
            c.modify_counter(saved_page_table[i].get_R());
            set_of_counters[i] = c;
        }
    }
}