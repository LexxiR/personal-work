/*
 * Lexxi Reddington 
 * Project 8: Paging
 * Operating Systems, Spring 2020
 */
 
#ifndef PROCESS_H
#define PROCESS_H

#include "PageTableEntry.h"
#include "Counter.h"

#include <vector>
#include <stdint.h>
#include <iomanip>
#include <math.h>

class Process {
private:
    uint32_t num_pages;
    uint32_t num_page_frames;
    std::vector<PageTableEntry> page_table;
    std::vector<PageTableEntry> saved_page_table;
    std::vector<Counter> set_of_counters;
public:
    Process(uint32_t num_pages, uint32_t num_page_frames);
    ~Process();
    // Accessors
    uint32_t get_num_pages();
    std::vector<PageTableEntry> get_page_table();
    std::vector<Counter> get_counters();
    bool get_last_added_value(uint32_t page_num);
    // Mutators and other helpers galore!
    void set_page_table_R(uint32_t location_in_vector, bool b);
    void set_page_table_M(uint32_t location_in_vector, bool b);
    void set_page_table_P(uint32_t location_in_vector, bool b);
    void set_counter_set(uint32_t location_in_vector, bool b);
    void update_entry(uint32_t location_in_vector, uint32_t frame);
    uint32_t update_entry_P(uint32_t location_in_vector, bool P);
    void update_entry_R(uint32_t location_in_vector, bool R);
    void set_last_added_value(uint32_t page_num, bool setter);
    void set_saved_page_table(std::vector<PageTableEntry> pg_tab);
    void modify_age_for_preloads(uint32_t location_in_vector);
    void set_counter(uint32_t location_in_vector);
    void reset(uint32_t location_in_vector);
    void replace(uint32_t location_in_vector, uint8_t val);
    // Function to age the counters
    void age_counters();
};

#endif // PROCESS_H
