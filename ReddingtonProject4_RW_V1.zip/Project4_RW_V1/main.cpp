/*
 * Lexxi Reddington 
 * Project 4: Readers and Writers
 * VERSION 1 (Favor the Readers)
 * Operating Systems, Spring 2020
 */
 
#include <iostream>
#include <ctime>
#include <pthread.h>
#include <unistd.h>

// Constants
const int NUM_READERS = 4;
const int NUM_WRITERS = 4;
const int n = 3;

// Shared variables
int shared_data{0};
int rc{0};

// Mutexes to protect shared data (critical region)
pthread_mutex_t mutex;
pthread_mutex_t db;
pthread_mutex_t output_mutex; // Added to fix output formatting

// Start routines
void *reader(void *arg);
void *writer(void *arg);

int main(int argc, char* argv[]) {    
    // Seed for random number generator
    std::srand(std::time(nullptr));
    
    pthread_mutex_init(&mutex, NULL);
    pthread_mutex_init(&db, NULL);
    pthread_mutex_init(&output_mutex, NULL);

    // Create reader threads
    pthread_t rtid[NUM_READERS];
    int reader_thread_number[NUM_READERS];

    for (int i = 0; i < NUM_READERS; ++i) {
        reader_thread_number[i] = i;
        int status = pthread_create(&rtid[i], NULL, reader, &reader_thread_number[i]);
        if (status != 0) {
            std::cerr << "Unable to create thread" << std::endl;
        }
    }
    
    // Join reader threads
    for (int i = 0; i < NUM_READERS; ++i) {
        pthread_join(rtid[i], NULL);
    }
    
    // Create writer threads
    pthread_t wtid[NUM_WRITERS];
    int writer_thread_number[NUM_WRITERS];

    for (int i = 0; i < NUM_WRITERS; ++i) {
        writer_thread_number[i] = i;
        int status = pthread_create(&wtid[i], NULL, writer, &writer_thread_number[i]);
        if (status != 0) {
            std::cerr << "Unable to create thread" << std::endl;
        }
    }
    
    // Join writer threads
    for (int i = 0; i < NUM_WRITERS; ++i) {
        pthread_join(wtid[i], NULL);
    }
    
    // Clean up
    pthread_mutex_destroy(&mutex);
    pthread_mutex_destroy(&db);
    pthread_mutex_destroy(&output_mutex);
    
	return 0;
}

// Start routine for readers
void *reader(void *arg) {
    int num = *static_cast<int *>(arg);

    for (int i = 0; i < n; ++i) {
        // Ensure mutual exclusion
        pthread_mutex_lock(&mutex);
        // Account for the additional reader
        rc += 1;
        // Lock the resource if this is the first reader
        if (rc == 1) pthread_mutex_lock(&db);
        pthread_mutex_unlock(&mutex);
        
        // Perform read
        usleep(rand()%90 + 10);
        pthread_mutex_lock(&output_mutex);
        std::cout << "reader " << num << " read " << shared_data << " " << rc << " reader(s)\n";
        pthread_mutex_unlock(&output_mutex);
        
        // Ensure mutual exclusion
        pthread_mutex_lock(&mutex);
        // Reader has finished
        rc -= 1;
        // If there are no pending readers, the writers may continue
        if (rc == 0) pthread_mutex_unlock(&db);
        pthread_mutex_unlock(&mutex);
    }
    pthread_exit(0);
}

// Start routine for writers
void *writer(void *arg) {
    int num = *static_cast<int *>(arg);
    
    for (int i = 0; i < n; ++i) {
        // Sleep thread randomly before entering Critical Region
        usleep(rand()%90 + 10);
        // Ensure mutual exclusion
        pthread_mutex_lock(&db);
        // Perform write
        shared_data = std::rand();
        std::cout << "writer " << num << " wrote " << shared_data << " " << rc << " readers(s)\n";
        pthread_mutex_unlock(&db);
    }
    pthread_exit(0);
}
