import java.awt.geom.Point2D;
/*
 * Introduction to Computer Science III
 * Assignment 5: Spatial Trees
 * Lexxi Reddington
 * November 18, 2018
 */
public class SpatialTreeNode {
	//Instance variables for each node
	private SpatialTreeNode left;
	private SpatialTreeNode right;
	private SpatialTreeNode parent;
	private Point2D myPoint;
	private boolean xNode; //True if x-node, false if y-node
	private double min = 0; //Based on canvas scale of 0 to 50
	private double max = 50; //Based on canvas scale of 0 to 50
	
	//Constructor
	public SpatialTreeNode(Point2D point) {
		myPoint = point;
		left = null;
		right = null;
		parent = null;
	}

	//GETTERS
	public boolean isXNode() {
		return xNode;
	}

	public double getX() {
		return myPoint.getX();
	}

	public double getY() {
		return myPoint.getY();
	}

	public SpatialTreeNode getLeft() {
		return left;
	}

	public SpatialTreeNode getRight() {
		return right;
	}

	public SpatialTreeNode getParent() {
		return parent;
	}

	public Point2D getPoint() {
		return myPoint;
	}
	
	public double getMin() {
		return min;
	}
	
	public double getMax() {
		return max;
	}

	//SETTERS
	public void setLeft(SpatialTreeNode l) {
		left = l;
	}

	public void setRight(SpatialTreeNode r) {
		right = r;
	}

	public void setParent(SpatialTreeNode p) {
		parent = p;
	}

	public void setXNode(boolean b) {
		xNode = b;
	}
	
	public void setMin(double d) {
		min = d;
	}
	
	public void setMax(double d) {
		max = d;
	}
}