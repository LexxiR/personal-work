import java.awt.Color;
import java.awt.geom.Point2D;
import java.util.Random;
import edu.princeton.cs.introcs.StdDraw;
/*
 * Introduction to Computer Science III
 * Assignment 5: Spatial Trees
 * Lexxi Reddington
 * November 18, 2018
 */
public class Driver {
	public static void main(String[] args) {
		StdDraw.setCanvasSize(750,750);
		StdDraw.setScale(0,50); //Canvas scale hard-coded for simplicity
		StdDraw.enableDoubleBuffering();

		Color t = new Color(255, 245, 63); //Color of query circle

		SpatialTree myTree = new SpatialTree();

		//Populate myTree with 100 random points
		for(int i = 0; i < 100; ++i) {
			Random rand = new Random();
			double x = rand.nextDouble()*50.0; //Range is 0 to 50
			double y = rand.nextDouble()*50.0; //Range is 0 to 50
			Point2D point = new Point2D.Double(x, y);
			myTree.add(point);
		}

		myTree.draw();
		StdDraw.show();
		
		while(true) {
			double centerX = StdDraw.mouseX();
			double centerY = StdDraw.mouseY();

			while(StdDraw.isMousePressed()) {
				myTree.draw();
				StdDraw.show();
				Point2D query = new Point2D.Double(centerX, centerY); //Center of query circle
				StdDraw.clear();
				myTree.clearQueryList();
				//Calculations for the size of the query circle drawn
				double newX = StdDraw.mouseX();
				double newY = StdDraw.mouseY();
				double distance = (((newX-centerX)*(newX-centerX)) + ((newY-centerY)*(newY-centerY)));
				double radius = Math.sqrt(distance);	
				StdDraw.setPenColor(t);
				StdDraw.filledCircle(centerX, centerY, radius); //Draw the query circle
				myTree.draw();
				myTree.drawQuery((myTree.query(query, radius)));
				StdDraw.show();
			}
		}
	}
}