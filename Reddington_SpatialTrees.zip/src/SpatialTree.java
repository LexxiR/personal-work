import java.awt.geom.Point2D;
import java.util.ArrayList;
import edu.princeton.cs.introcs.StdDraw;
/*
 * Introduction to Computer Science III
 * Assignment 5: Spatial Trees
 * Lexxi Reddington
 * November 18, 2018
 */
public class SpatialTree {
	private SpatialTreeNode root;
	private ArrayList<SpatialTreeNode> nodeList = new ArrayList<>(); //Contains all nodes in myTree
	private ArrayList<Point2D> queryList = new ArrayList<>(); //Contains all points inside query circle
	private ArrayList<Point2D> emptyList = new ArrayList<>(); //Contains the points to be removed from the query circle

	//Constructor
	public void SpatialTree() {
		root = null;
	}

	//Adds a point to the tree
	public SpatialTreeNode add(Point2D point) {
		if(root == null) {
			root = new SpatialTreeNode(point);
			root.setXNode(true);
			setLinePoints(root);
			nodeList.add(root);
			return root;
		} else {
			return addHelper(point, root);
		}
	}

	//Add helper method
	private SpatialTreeNode addHelper(Point2D point, SpatialTreeNode node) {
		SpatialTreeNode n = null;
		if(node.isXNode() == true) { //Process for x-nodes
			if(point.getX() <= node.getX()) { //Node belongs in left subtree
				if(node.getLeft() == null) {
					//ADD
					n = new SpatialTreeNode(point);
					n.setXNode(false); //Is a y-node
					node.setLeft(n); //Now the parent "node" has a left child "n"
					n.setParent(node);
					nodeList.add(n);
				} else { //Recursion
					node = node.getLeft();
					addHelper(point, node);
				}
			} else { //Node belongs in right subtree
				if(node.getRight() == null) {
					//ADD
					n = new SpatialTreeNode(point);
					n.setXNode(false); //Is a y-node
					node.setRight(n); //Now the parent "node" has a right child "n"
					n.setParent(node);
					nodeList.add(n);
				} else { //Recursion
					node = node.getRight();
					addHelper(point, node);
				}
			}
		} else { //Process for y-nodes
			if(point.getY() <= node.getY()) { //Node belongs in left subtree
				if(node.getLeft() == null) {
					//ADD
					n = new SpatialTreeNode(point);
					n.setXNode(true); //Is a x-node
					node.setLeft(n); //Now the parent "node" has a left child "n"
					n.setParent(node);
					nodeList.add(n);
				} else { //Recursion
					node = node.getLeft();
					addHelper(point, node);
				}
			} else { //Node belongs in right subtree
				if(node.getRight() == null) {
					//ADD
					n = new SpatialTreeNode(point);
					n.setXNode(true); //Is a x-node
					node.setRight(n); //Now the parent "node" has a right child "n"
					n.setParent(node);
					nodeList.add(n);
				} else { //Recursion
					node = node.getRight();
					addHelper(point, node);
				}
			}
		}
		return n;
	}

	//Draws the spatial tree
	public void draw() {
		for(SpatialTreeNode node: nodeList) {
			setLinePoints(node);
			if(node.isXNode()) {
				StdDraw.setPenColor(StdDraw.RED);
				StdDraw.line(node.getX(), node.getMin(), node.getX(), node.getMax());
			} else {
				StdDraw.setPenColor(StdDraw.BLUE);
				StdDraw.line(node.getMin(), node.getY(), node.getMax(), node.getY());
			}
			StdDraw.setPenColor(StdDraw.BLACK);
			StdDraw.filledCircle(node.getX(), node.getY(), 0.5);   
		}
	}

	//Draw helper method 1
	public void drawHelper(SpatialTreeNode node) {
		StdDraw.setPenColor(StdDraw.BLACK);
		if(node.getLeft() != null) {
			StdDraw.filledCircle(node.getLeft().getX(), node.getLeft().getY(), 0.5);
		}
		if(node.getRight() != null) {
			StdDraw.filledCircle(node.getRight().getX(), node.getRight().getY(), 0.5);
		}
	}

	//Draw helper method 2 - Determines the coordinates of the spatial lines for each node
	private void setLinePoints(SpatialTreeNode node) {
		SpatialTreeNode temp = node;
		if(node.isXNode() == true) { //Process for x-nodes
			while(temp.getParent() != null) {
				temp = temp.getParent();
				if(temp.isXNode() == false) {
					if(node.getY() > temp.getY() && node.getMin() < temp.getY()) {
						node.setMin(temp.getY());
					}
					if(node.getY() < temp.getY() && node.getMax() > temp.getY()) {
						node.setMax(temp.getY());
					}
				}
			}
		} else { //Process for y-nodes
			while(temp.getParent() != null) {
				temp = temp.getParent();
				if(temp.isXNode() == true) {
					if(node.getX() > temp.getX() && node.getMin() < temp.getX()) {
						node.setMin(temp.getX());
					}
					if(node.getX() < temp.getX() && node.getMax() > temp.getX()) {
						node.setMax(temp.getX());
					}
				}
			}
		}
	}

	//Highlights the points within the query circle
	public void drawQuery(ArrayList<Point2D> al) {
		for(Point2D p: al) {
			StdDraw.setPenColor(StdDraw.BLUE);
			StdDraw.filledCircle(p.getX(), p.getY(), 0.5);
		}
	}

	//Clears the queryList so a new search can be performed when a new query circle is drawn
	public void clearQueryList() {
		for(Point2D p: queryList) {
			emptyList.add(p);
		}
		for(Point2D p: emptyList) {
			queryList.remove(p);
		}
	}

	//Returns a list of all points contained inside the query circle
	public ArrayList<Point2D> query(Point2D center, double radius) {
		queryHelper(root, center, radius);
		return queryList;
	}

	//Query helper method - used for efficiency to only search the necessary subtrees
	private void queryHelper(SpatialTreeNode node, Point2D center, double radius) {
		//Check if the node itself should be included in the query circle
		if(center.distance(node.getX(), node.getY()) <= radius) {
			queryList.add(node.getPoint());
		}
		if(node.isXNode() == true) { //Process for x-nodes
			if(center.distance(node.getX(), center.getY()) >= radius) { //Search only one subtree
				if(center.getX() > node.getX()) { //Search right subtree
					if(node.getRight() != null) {
						queryHelper(node.getRight(), center, radius);
					}
				} else { //Search left subtree
					if(node.getLeft() != null) {
						queryHelper(node.getLeft(), center, radius);
					}
				}
			} else { //Search both subtrees
				if(node.getRight() != null) {
					queryHelper(node.getRight(), center, radius);
				} 
				if(node.getLeft() != null) {
					queryHelper(node.getLeft(), center, radius);
				}
			}
		} else { //Process for y-nodes
			if(center.distance(center.getX(), node.getY()) >= radius) { //Search only one subtree
				if(center.getY() > node.getY()) { //Search right subtree
					if(node.getRight() != null) {
						queryHelper(node.getRight(), center, radius);
					}
				} else { //Search left subtree
					if(node.getLeft() != null) {
						queryHelper(node.getLeft(), center, radius);
					}
				}
			} else { //Search both subtrees
				if(node.getRight() != null) {
					queryHelper(node.getRight(), center, radius);
				}
				if(node.getLeft() != null) {
					queryHelper(node.getLeft(), center, radius);
				}
			}
		}
	}

	//toString method used for debugging
	public String toString() {
		StringBuilder sb = new StringBuilder();
		toString(root, sb, 0);
		return sb.toString();
	}

	//toString helper method
	private void toString(SpatialTreeNode node, StringBuilder sb, int level) {
		if(node != null) {
			for(int i = 0; i < 2*level; i++) {
				sb.append(" ");
			}
			sb.append(node.getPoint().toString() + "\n");
			toString(node.getLeft(), sb, level+1);
			toString(node.getRight(), sb, level+1);
		}
	}
}