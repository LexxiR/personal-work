import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import edu.princeton.cs.introcs.StdDraw;
/*
 * Name: Lexxi Reddington
 * Assignment Number: 1 
 * Date: April 1, 2018
 * File Name: ReddingtonLexxiProject1
 * Description: Game of Life - A simulation that runs a two-dimensional array and specifies, for each cell, whether occupied by a creature or empty.
 */
public class Environment {
	private int numRows;
	private int numCols;
	private Cell[][] array;

	private int neighbors = 0;

	public Environment(String file) {
		//Declare 'data'
		Scanner data = null;

		//Import file
		try {
			data = new Scanner(new FileInputStream(file));
		} catch(FileNotFoundException e) {
			System.out.println("File not found");
			System.exit(0);
		}

		//Read from file; populate array 
		numRows = data.nextInt();
		numCols = data.nextInt();

		array = new Cell[numRows][numCols];

		for(int i=0; i < numRows; ++i) {
			for(int j=0; j < numCols; ++j) {
				if(data.nextInt() == 0) {
				array[i][j] = new Cell(false); 
				}
				else {
				array[i][j] = new Cell(true); 
				}
			}
		}

		StdDraw.setCanvasSize(20*numCols,20*numRows);
		StdDraw.setXscale(0,numCols);
		//Flip the y-axis (Compensate for StdDraw starting from the bottom corner instead of the top)
		StdDraw.setYscale(numRows, 0);
	}

	//Rules of the game:
	//1. Any living creature (occupied cell) with fewer than two live neighbors dies of loneliness.
	//2. Any living creature with two or three live neighbors lives on to the next generation.
	//3. Any living creature with more than three live neighbors dies of overcrowding.
	//4. Any empty cell with exactly three live neighbors becomes an occupied cell. This represents a birth.

	public void runSimulation() {
		displayGrid();
		while(true) {
			createNextGen();
			StdDraw.pause(300);
			StdDraw.clear();
			displayGrid();				
		}
	}

	//Method to display the Game of Life graphically/with StdDraw
	public void displayGrid() {
		for(int i = 0; i < numRows; ++i) {
			for(int j = 0; j < numCols; ++j) {
				if(array[i][j].getOccupied() == true) {
					StdDraw.filledSquare(j+0.5, i+0.5, 0.5);
				}
			}
		}
	}

	//Method to create the next generation, depending on the number of neighbors calculated 
	public void createNextGen() {
		Cell[][] arrayTemp = new Cell[numRows][numCols];
		for(int i = 0; i < numRows; ++i) {
			for(int j = 0; j < numCols; ++j) {
				neighbors(i, j);
				if(array[i][j].getOccupied() == true) {
					if(neighbors < 2) {
						arrayTemp[i][j] = new Cell(false);
					}
					else if(neighbors > 3) {
						arrayTemp[i][j] = new Cell(false);
					}
					else {
						arrayTemp[i][j] = new Cell(true);
					}
				}
				else if(array[i][j].getOccupied() == false) {
					if(neighbors == 3) {
						arrayTemp[i][j] = new Cell(true);
					}
					else {
						arrayTemp[i][j] = new Cell(false);
					}
				}
			}
		}
		array = arrayTemp;
	}

	//Method to determine the number of neighbors each cell has 
	public void neighbors(int i, int j) {
		neighbors = 0;
		//Neighbors for the four corners of the array
		if(i-1 < 0 && j-1 < 0) {
			for(int h = 0; h < 2; ++h) {
				for(int g = 0; g < 2; ++g) {
					if(!(h==i && g==j)) {
						if(array[h][g].getOccupied() == true) {
							++neighbors;
						}
					}
				}
			}
		}

		else if(i-1 < 0 && j+1 > numCols-1) {
			for(int h = 0; h < 2; ++h) {
				for(int g = j-1; g < j+1; ++g) {
					if(!(h==i && g==j)) {
						if(array[h][g].getOccupied() == true) {
							++neighbors;
						}
					}
				}
			}
		}

		else if(i+1 > numRows-1 && j-1 < 0) {
			for(int h = i-1; h < i+1; ++h) {
				for(int g = 0; g < 2; ++g) {
					if(!(h==i && g==j)) {
						if(array[h][g].getOccupied() == true) {
							++neighbors;
						}
					}
				}
			}
		}

		else if(i+1 > numRows-1 && j+1 > numCols-1) {
			for(int h = i-1; h < i+1; ++h) {
				for(int g = j-1; g < j+1; ++g) {
					if(!(h==i && g==j)) {
						if(array[h][g].getOccupied() == true) {
							++neighbors;
						}
					}
				}
			}
		}

		//Neighbors for the edges of the array
		else if(i-1 < 0) {
			for(int h = 0; h < 2; ++h) {
				for(int g = j-1; g < j+2; ++g) {
					if(!(h==i && g==j)) {
						if(array[h][g].getOccupied() == true) {
							++neighbors;
						}
					}
				}
			}
		}

		else if(i+1 > numRows-1) {
			for(int h = i-1; h < i+1; ++h) {
				for(int g = j-1; g < j+2; ++g) {
					if(!(h==i && g==j)) {
						if(array[h][g].getOccupied() == true) {
							++neighbors;
						}
					}
				}
			}
		}

		else if(j-1 < 0) {
			for(int h = i-1; h < i+2; ++h) {
				for(int g = 0; g < 2; ++g) {
					if(!(h==i && g==j)) {
						if(array[h][g].getOccupied() == true) {
							++neighbors;
						}
					}
				}
			}
		}

		else if(j+1 > numCols-1) {
			for(int h = i-1; h < i+2; ++h) {
				for(int g = j-1; g < j+1; ++g) {
					if(!(h==i && g==j)) {
						if(array[h][g].getOccupied() == true) {
							++neighbors;
						}
					}
				}
			}
		}

		//Neighbors for the rest of the array cells
		else {
			for(int h = i-1; h < i+2; ++h) {
				for(int g = j-1; g < j+2; ++g) {
					if(!(h==i && g==j)) {
						if(array[h][g].getOccupied() == true) {
							++neighbors;
						}
					}
				}
			}
		}
	}
}