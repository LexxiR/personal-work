
public class EnvironmentDriver {
	/*
	 * Name: Lexxi Reddington
	 * Assignment Number: 1 
	 * Date: April 1, 2018
	 * File Name: ReddingtonLexxiProject1
	 * Description: Game of Life - A simulation that runs a two-dimensional array and specifies, for each cell, whether occupied by a creature or empty.
	 */
	public static void main(String[] args) {
		//Note: Change the filename to test the four different simulations 
		String filename = "GameOfLife3.txt";
	    Environment e = new Environment(filename);
	    e.runSimulation();
	}
}
