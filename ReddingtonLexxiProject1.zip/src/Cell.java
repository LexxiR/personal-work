/*
 * Name: Lexxi Reddington
 * Assignment Number: 1 
 * Date: April 1, 2018
 * File Name: ReddingtonLexxiProject1
 * Description: Game of Life - A simulation that runs a two-dimensional array and specifies, for each cell, whether occupied by a creature or empty.
 */
public class Cell {
	//True if the cell is occupied; false if the cell is not occupied
	private boolean occupied;

	public Cell(boolean isOccupied) {
		if(isOccupied == true) {
			occupied = true;
		}
		else if(isOccupied == false) {
			occupied = false;
		}
	}
	
	public boolean getOccupied() {
		return occupied;
	}
}
