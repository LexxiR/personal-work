package unstddraw;
import edu.princeton.cs.introcs.StdDraw;
import java.util.Random;
import java.awt.Color;
import java.awt.Font;
/*
 * 
 * Author: Lexxi Reddington
 * Project 2: A class with static methods that add some extra features to StdDraw (without modifying StdDraw itself)
 * Date: April 16, 2018
 *  
 */
public class UnStdDraw { 
	private static double angleN;
	private static double angleS;
	private static int nGonCount = 0;
	private static int spiralCount = 0;
	
	//New color constants 
	public static final Color HOTPINK = new Color(255, 0, 93);
	public static final Color COOLBLUE = new Color(0, 187, 255);
	public static final Color MELLOWYELLOW = new Color(255, 246, 89);

	//Method to draw a regular nGon (a polygon with n sides, all the same length, all with equal angles)
	public static void filledRegularNgon(double centerX, double centerY, double radius, int n) {
		angleN = 2*Math.PI/n;
		double[] xPoints = new double[n];
		double[] yPoints = new double[n];
		for(int i=0; i<n; ++i) {
			xPoints[i] = centerX + radius * Math.cos(i*angleN);
			yPoints[i] = centerY + radius * Math.sin(i*angleN);
		}
		StdDraw.filledPolygon(xPoints, yPoints);
		++nGonCount;
	}

	//Method to draw a spiral centered at (x, y)
	public static void spiral(double centerX, double centerY, double maxRadius, int spinRate, int numSegments) {
		double radius = 0; 
		angleS = 2*Math.PI/numSegments*spinRate;
		double[] xPoints = new double[numSegments];
		double[] yPoints = new double[numSegments];
		for(int i=0; i<numSegments; ++i) {
			xPoints[i] = centerX + radius * Math.cos(i*angleS);
			yPoints[i] = centerY + radius * Math.sin(i*angleS);
			radius = radius + (maxRadius/numSegments);
			if(i>0) {
				StdDraw.setPenRadius(0.01);
				StdDraw.line(xPoints[i-1], yPoints[i-1], xPoints[i], yPoints[i]);
			}
		}
		++spiralCount;
	}

	//Method to count how many times the filledRegularNgon() method is called
	public static int getNGonCount() {
		return nGonCount;
	}
	
	//Method to count how many times the spiral() method is called
	public static int getSpiralCount() {
		return spiralCount;
	}
}
