package unstddraw;
import edu.princeton.cs.introcs.StdDraw;
/*
 * 
 * Author: Lexxi Reddington
 * Project 2: A class with static methods that add some extra features to StdDraw (without modifying StdDraw itself)
 * Date: April 16, 2018
 *  
 */
public class Driver {

	public static void main(String[] args) {
		//Set canvas size and scale
		StdDraw.setCanvasSize(800,800);
		StdDraw.setScale(-100,100);
		
		//Draw spirals
		StdDraw.setPenColor(UnStdDraw.COOLBLUE);
		UnStdDraw.spiral(-40, 50, 30, 4, 1000);
		UnStdDraw.spiral(40, 50, 30, 4, 1000);
		
		//Draw nGons
		StdDraw.setPenColor(UnStdDraw.MELLOWYELLOW);
		UnStdDraw.filledRegularNgon(0,0,20,3);
		
		StdDraw.setPenColor(UnStdDraw.HOTPINK);
		UnStdDraw.filledRegularNgon(0,-60,8,8);
		UnStdDraw.filledRegularNgon(20,-55,8,8);
		UnStdDraw.filledRegularNgon(-20,-55,8,8);
		UnStdDraw.filledRegularNgon(40,-45,8,8);
		UnStdDraw.filledRegularNgon(-40,-45,8,8);
		
		//Return the number of nGons and spirals
		System.out.println("nGon Count: " + UnStdDraw.getNGonCount());
		System.out.println("Spiral Count: " + UnStdDraw.getSpiralCount());
	}
}
