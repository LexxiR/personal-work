/*
 * Lexxi Reddington 
 * Project 3: Perfect Numbers
 * VERSION: C++ Threads
 * Operating Systems, Spring 2020
 */

#include <iostream>
#include <vector>
#include <math.h>
#include <thread>
#include <mutex>

// Shared variables
uint64_t num_factors{0};
std::array<uint64_t, 100> shared_buffer;
uint64_t buffer_index{0};

// Mutex to protect shared data (critical region)
std::mutex mutex;

// Function to determine if a number is a factor of another
void find_factors(uint64_t number, uint64_t start_index, uint64_t end_index);

int main(int argc, char* argv[]) {
    // User input
	std::cout << "Enter number: \n";
    uint64_t number;
    std::cin >> number;
    std::cout << "Number of threads: \n";
    uint64_t num_threads;
    std::cin >> num_threads;
    
    // Thread set up to partition number
	std::vector<std::thread> threads;
    uint64_t set_size = ceil((static_cast<double>(number) / 2) / num_threads);

    // Create threads
    for (uint64_t i = 0; i < num_threads; ++i) {
        uint64_t start_index = 1 + (set_size * i);
        uint64_t end_index = set_size + (set_size * i);
        if (end_index > number / 2) {
            end_index = number / 2;
        }
        threads.push_back(std::thread {find_factors, number, start_index, end_index});
    }
    
    // Join threads
    for (std::thread &t: threads) {
          t.join();
    }
    
    // Print out each factor
    std::cout << "\nNumber of factors is: " << num_factors << "\n";
    uint64_t sum = 0;
    
    for (uint64_t factor : shared_buffer) {
        sum += factor;
        if(factor == 0) break; 
        std::cout << factor << "\n";
    }
    
    // Determine if the number is perfect
    if (sum == number) {
        std::cout << "\n" << number << " is a perfect number!\n";
    } else {
        std::cout << "\n" << number << " is not a perfect number.\n";
    }
	return 0;
}

// Start routine
void find_factors(uint64_t number, uint64_t start_index, uint64_t end_index) {
    // Determine the factors
    for (uint64_t i = start_index; i <= end_index; ++i) {
        if (number % i == 0) { 
            // Write factor to the shared buffer
            mutex.lock();
            shared_buffer[buffer_index] = i;
            ++buffer_index;
            ++num_factors;
            mutex.unlock();
        } 
    } 
}
