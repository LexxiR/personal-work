package project5;

import java.awt.Color;

import edu.princeton.cs.introcs.StdDraw;

/*
 * 
 * Author: Lexxi Reddington
 * File Name: Reddington_Windows
 * Assignment 5: A program that models a list of possibly overlapping rectangular two-dimensional windows
 * Date: May 17, 2018
 *  
 */
public class Window {
	private double x;
	private double y;
	private double width;
	private double height;
	private Color color;
	
	//Constructor with no parameters
	public Window() {
		x = 0;
		y = 0;
		width = 0;
		height = 0;
		color = Color.BLACK;
	}
	
	//Constructor with parameters
	public Window(double x, double y, double width, double height, Color color) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.color = color;
	}
	
	//Draw method for an individual window 
	public void draw() {
		StdDraw.setPenColor(color);
		StdDraw.filledRectangle(x, y, width/2, height/2);
	}
	
	//Method to determine if two coordinates are within a given window
	public boolean withinWindow(double otherX, double otherY) {
		if(otherX > x + (width*0.5) || otherX < x - (width*0.5)) {
			return false;
		}
		if(otherY > y + (height*0.5) || otherY < y - (height*0.5)) {
			return false;
		}
		else {
			return true;
		}
	}
}