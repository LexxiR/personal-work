package project5;

import java.util.ArrayList;
import edu.princeton.cs.introcs.StdDraw;

/*
 * 
 * Author: Lexxi Reddington
 * File Name: Reddington_Windows
 * Assignment 5: A program that models a list of possibly overlapping rectangular two-dimensional windows
 * Date: May 17, 2018
 *  
 */
public class WindowDisplay {
	private ArrayList<Window> list;
	private int canvasWidth;
	private int canvasHeight;

	//Constructor with no parameters 
	public WindowDisplay() {
		//Canvas width and height (scale) are set to the default (0 to 1) 
		//Canvas size default is 512-by-512 pixels
		list = new ArrayList();
	}

	//Constructor with parameters 
	public WindowDisplay(int canvasWidth, int canvasHeight) {
		this.canvasWidth = canvasWidth;
		this.canvasHeight = canvasHeight;
		list = new ArrayList();
		StdDraw.setCanvasSize(canvasWidth*4, canvasHeight*4);
		StdDraw.setXscale(0, canvasWidth);
		StdDraw.setYscale(canvasHeight, 0);
	}

	//Method to add a window to the array list 
	public void addWindow(Window window) {
		list.add(window);
	}

	//Method to run the simulation 
	public void run() {
		StdDraw.enableDoubleBuffering();
		while(true) {
			displayWindows();
			clicked();
			StdDraw.show();
			StdDraw.clear();
		}
	}

	//Helper method to draw all of the windows
	private void displayWindows() {
		for(int i = 0; i < list.size(); ++i) {
			list.get(i).draw();
		}
	}

	//Helper method to determine if a window is clicked (if clicked, window moves to the top)
	private void clicked() {
		for(int i = list.size() - 1; i >= 0; --i) {
			if(StdDraw.isMousePressed() && list.get(i).withinWindow(StdDraw.mouseX(), StdDraw.mouseY())) {
				Window temp = list.get(i);
				list.remove(temp);
				list.add(temp);
				break;
			} 
		}
	}
}