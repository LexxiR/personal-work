/*
 * Lexxi Reddington 
 * Project 7: Memory Management with Lists
 * Operating Systems, Spring 2020
 */
 
#include "MemoryManager.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

// Constructor to read the input file
MemoryManager::MemoryManager(std::string input_file) {
    // Open input file
    std::ifstream in(input_file);
    if (!in.is_open()) {
        std::cerr << "Error: Couldn't open file." << std::endl;
    } else {
        // Read the input file
        std::string line;
        while (std::getline(in, line)) {
            file.push_back(line);
        }
    }
}

// Destructor
MemoryManager::~MemoryManager() {}

// Memory Manager simulation 
void MemoryManager::run() {
    // The first line of the input file contains a string and a single integer
    std::istringstream ss(file[0]);
    std::string alg;
    ss >> alg;
    ss >> total_memory;
    
    // The simulation begins with one hole
    MemoryChunk mc("hole", 0, total_memory);
    memory_list.push_back(mc);
    print_memory();
    
    // Iterate over each line of the file (every command)
    for (uint i = 1; i < file.size(); ++i) {
        std::cout << file[i] << "\n";
        std::istringstream ss(file[i]);
        std::string command;
        ss >> command;
        std::string process_name;
        if (command.compare("load") == 0) {
            ss >> process_name;
            int memory_request;
            ss >> memory_request;
            
            // Manage the load request, depending on the desired algorithm
            if (alg.compare("firstFit") == 0) {
                first_fit_load(process_name, memory_request);
            } else if (alg.compare("bestFit") == 0) {
                best_fit_load(process_name, memory_request);
            } else {
                worst_fit_load(process_name, memory_request);
            }
            
        } else {
            ss >> process_name;
            // Manage the unload request, depending on the desired algorithm
            if (alg.compare("firstFit") == 0) {
                unload(process_name);
            } else if (alg.compare("bestFit") == 0) {
                unload(process_name);
            } else {
                unload(process_name);
            }
        }
        print_memory();
    }
}

// Private helper function to perform the firstFit algorithm
void MemoryManager::first_fit_load(std::string process_name, int memory_request) {
    // Scan memory_list until a large enough hole is found
    bool flag = false;
    for (std::list<MemoryChunk>::iterator it = memory_list.begin(); it != memory_list.end(); ++it) {
        MemoryChunk mc = *it;
        if (mc.get_name().compare("hole") == 0) {
            // There is a hole, is it big enough?
            if (mc.get_size() >= memory_request) {
                // There is a hole of sufficient size
                // Break up hole into two pieces: process and remainder (hole)
                MemoryChunk process(process_name, mc.get_start_add(), memory_request);
                MemoryChunk remainder("hole", mc.get_start_add() + memory_request, mc.get_size() - memory_request);
                
                // Add these new pieces to memory
                memory_list.insert(it, process);
                if (remainder.get_size() > 0) memory_list.insert(it, remainder);
                
                MemoryChunk curr = *it;
                // The iterator is invalid after deletion to return the next
                it = memory_list.erase(it);
                // We are done searching, so end the for loop
                it = --memory_list.end();
                // Indicate the process was sucessfully loaded into memory
                flag = true;
            }
        }
    }
    if (!flag) std::cout << "Unable to load process " << process_name << "\n";
}

// Private helper function to perform the bestFit algorithm
void MemoryManager::best_fit_load(std::string process_name, int memory_request) {
    std::list<MemoryChunk>::iterator saved_it = memory_list.begin();
    MemoryChunk smallest_hole("temp", 0, total_memory * 2);
    // Scan the entire memory_list to find the smallest adequate hole
    for (std::list<MemoryChunk>::iterator it = memory_list.begin(); it != memory_list.end(); ++it) {
        MemoryChunk mc = *it;

        if (mc.get_name().compare("hole") == 0) {
            if (mc.get_size() < smallest_hole.get_size() && mc.get_size() >= memory_request) {
                int size = mc.get_size();
                smallest_hole.set_size(size);
                int start_add = mc.get_start_add();
                smallest_hole.set_start_add(start_add);
                std::string name = "hole";
                smallest_hole.set_name(name);
                saved_it = it;
            }
        }
    }
    if (smallest_hole.get_name().compare("hole") == 0) {
        saved_it = memory_list.erase(saved_it);
        // Add these new pieces to memory
        MemoryChunk process(process_name, smallest_hole.get_start_add(), memory_request);
        MemoryChunk remainder("hole", smallest_hole.get_start_add() + memory_request, smallest_hole.get_size() - memory_request);
        memory_list.push_back(process);
        if (remainder.get_size() > 0) memory_list.push_back(remainder);
        memory_list.sort(MemoryChunkComparator());
    } else {
        std::cout << "Unable to load process " << process_name << "\n";
    }
}

// Private helper function to perform the worstFit algorithm
void MemoryManager::worst_fit_load(std::string process_name, int memory_request) {
    std::list<MemoryChunk>::iterator saved_it = memory_list.begin();
    MemoryChunk largest_hole("temp", 0, 0);
    // Scan the entire memory_list to find the largest adequate hole
    for (std::list<MemoryChunk>::iterator it = memory_list.begin(); it != memory_list.end(); ++it) {
        MemoryChunk mc = *it;

        if (mc.get_name().compare("hole") == 0) {
            if (mc.get_size() > largest_hole.get_size() && mc.get_size() >= memory_request) {
                int size = mc.get_size();
                largest_hole.set_size(size);
                int start_add = mc.get_start_add();
                largest_hole.set_start_add(start_add);
                std::string name = "hole";
                largest_hole.set_name(name);
                saved_it = it;
            }
        }
    }
    if (largest_hole.get_name().compare("hole") == 0) {
        saved_it = memory_list.erase(saved_it);
        // Add these new pieces to memory
        MemoryChunk process(process_name, largest_hole.get_start_add(), memory_request);
        MemoryChunk remainder("hole", largest_hole.get_start_add() + memory_request, largest_hole.get_size() - memory_request);
        memory_list.push_back(process);
        if (remainder.get_size() > 0) memory_list.push_back(remainder);
        memory_list.sort(MemoryChunkComparator());
    } else {
        std::cout << "Unable to load process " << process_name << "\n";
    }
}

// Private helper function to perform unload requests
void MemoryManager::unload(std::string process_name) {
    // Search for process 'process_name' in memory_list to unload it
    for (std::list<MemoryChunk>::iterator it = memory_list.begin(); it != memory_list.end(); ++it) {
        MemoryChunk mc = *it;
        if (mc.get_name().compare(process_name) == 0){
            // We have found the process to unload (change to "hole")
            it = memory_list.erase(it);
            --it;
            std::string name = "hole";
            mc.set_name(name);
            memory_list.push_back(mc);
            memory_list.sort(MemoryChunkComparator());
        }
    }
    // Call the helper functions to merge consecutive holes
    std::list<MemoryChunk>::iterator ret = find_holes();
    std::list<MemoryChunk> list = delete_holes(ret);
    final_delete(list);
}

// Private helper function to find the locations of consecutive holes
std::list<MemoryChunk>::iterator MemoryManager::find_holes() {
    bool left_is_hole = false;
    bool self_is_hole = false;
    MemoryChunk left_neighbor("temp", 0, 0);
    
    std::list<MemoryChunk>::iterator saved_it = memory_list.end();
    for (std::list<MemoryChunk>::iterator it = memory_list.begin(); it != memory_list.end(); ++it) {
        MemoryChunk self = *it;
        if (left_neighbor.get_name().compare("hole") == 0) left_is_hole = true;
        if (self.get_name().compare("hole") == 0) self_is_hole = true;
        if (left_is_hole && self_is_hole) { 
            return saved_it;
        }
        saved_it = it;
        left_neighbor = self;
        left_is_hole = false;
        self_is_hole = false;
    }
    return memory_list.end();
}

// Private helper function to delete consecutive holes
std::list<MemoryChunk> MemoryManager::delete_holes(std::list<MemoryChunk>::iterator saved_it) {
    std::list<MemoryChunk> holes_to_delete;
    std::list<MemoryChunk>::iterator last_chunk_position = memory_list.end();
    --last_chunk_position;
    
    bool flag = false;
    
    if (saved_it != memory_list.end()) {
        MemoryChunk chunky = *saved_it;
        while (chunky.get_name().compare("hole")== 0 && !flag) {
            holes_to_delete.push_back(chunky);
            ++saved_it;
            if (saved_it != memory_list.end()) chunky = *saved_it;
            else flag = true;
        }                
    }
    return holes_to_delete;
}

// Private helper function to delete consecutive holes
void MemoryManager::final_delete(std::list<MemoryChunk> list) {
    MemoryChunk mc("hole", -1, 0);
    int start_add = -1;
    int size = 0;
    bool first = false;
    while (list.size() > 0) {
        
        MemoryChunk compare(list.front());
        list.pop_front();
        std::list<MemoryChunk>::iterator saved_it = memory_list.end();
        for (std::list<MemoryChunk>::iterator it = memory_list.begin(); it != memory_list.end(); ++it) {
            MemoryChunk chunky = *it;
            if (chunky.get_name().compare(compare.get_name()) == 0 && chunky.get_start_add() == compare.get_start_add() && chunky.get_size() == compare.get_size()) {
                saved_it = it;
            }
        }
        if (saved_it != memory_list.end()) {
            mc = *saved_it;
            if (!first) {
                start_add = mc.get_start_add();
            }
            size += mc.get_size();
            saved_it = memory_list.erase(saved_it);
            first = true;
            mc.set_start_add(start_add);
            mc.set_size(size);
        }
    }
    if (mc.get_size() > 0 && mc.get_start_add() > -1) {
        memory_list.push_back(mc);
        memory_list.sort(MemoryChunkComparator());
    }
}
   
// Private helper function to print the contents of memory_list
void MemoryManager::print_memory() {
    for (MemoryChunk mc : memory_list) {
        mc.print();
    }
    std::cout << "\n";
}