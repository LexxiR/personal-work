/*
 * Lexxi Reddington 
 * Project 7: Memory Management with Lists
 * Operating Systems, Spring 2020
 */
 
#ifndef MEMORYMANAGER_H
#define MEMORYMANAGER_H

#include "MemoryChunk.h"
#include <iostream>
#include <vector>
#include <list>

class MemoryManager {
private:
    // Member variables
    std::vector<std::string> file;
    std::list<MemoryChunk> memory_list; // C++ List Class
    int total_memory;
    
    // Load functions
    void first_fit_load(std::string process_name, int memory_request);
    void best_fit_load(std::string process_name, int memory_request);
    void worst_fit_load(std::string process_name, int memory_request);
    
    void print_memory();
    void unload(std::string process_name);
    
    // Helper functions for unload
    std::list<MemoryChunk>::iterator find_holes();
    std::list<MemoryChunk> delete_holes(std::list<MemoryChunk>::iterator saved_it);
    void final_delete(std::list<MemoryChunk> list);

public:
    MemoryManager(std::string input_file);
    ~MemoryManager();
    void run();
};

#endif // MEMORYMANAGER_H