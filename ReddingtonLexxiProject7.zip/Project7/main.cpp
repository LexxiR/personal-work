/*
 * Lexxi Reddington 
 * Project 7: Memory Management with Lists
 * Operating Systems, Spring 2020
 */

#include "MemoryManager.h" 
#include <iostream>

int main(int argc, char* argv[]) {
	// Check the number of command line arguments provided
    if (argc != 2) {
        // Tell the user how to run the program
        std::cerr << "Usage: " << argv[0] << " <input filename>" << std::endl;
        return 1;
    }
    // Create an object of type MemoryManager
    MemoryManager MM(argv[1]);
    // Call the MemoryManager object’s run method to start the simulation
    MM.run();
	return 0;
}