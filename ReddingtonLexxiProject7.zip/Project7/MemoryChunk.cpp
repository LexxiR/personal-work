/*
 * Lexxi Reddington 
 * Project 7: Memory Management with Lists
 * Operating Systems, Spring 2020
 */
 
#include "MemoryChunk.h"

MemoryChunk::MemoryChunk(std::string name, int start_add, int size) {
    this->name = name;
    this->start_add = start_add;
    this->size = size;
}

MemoryChunk::~MemoryChunk() {}

std::string MemoryChunk::get_name() const {
    return name;
}

int MemoryChunk::get_start_add() const {
    return start_add;
}

int MemoryChunk::get_size() const {
    return size;
}

void MemoryChunk::set_name(std::string &n) {
    this->name = n;
}

void MemoryChunk::set_start_add(int &sa) {
    this->start_add = sa;
}

void MemoryChunk::set_size(int &s) {
    this->size = s;
}

void MemoryChunk::print() {
    std::cout << name << ": start " << start_add << ", size: " << size << std::endl;
}