/*
 * Lexxi Reddington 
 * Project 7: Memory Management with Lists
 * Operating Systems, Spring 2020
 */
 
#ifndef MEMORYCHUNK_H
#define MEMORYCHUNK_H

#include <iostream>

class MemoryChunk {
private:
    std::string name;
    int start_add;
    int size;    
public:
    MemoryChunk(std::string name, int start_add, int size);
    ~MemoryChunk();
    // Accessors 
    std::string get_name() const;
    int get_start_add() const;
    int get_size() const;
    // Mutators
    void set_name(std::string &n);
    void set_start_add(int &sa);
    void set_size(int &s);
    // Print out the memory chunk
    void print();
};

// Comparator to sort MemoryChunk objects
struct MemoryChunkComparator {
    bool operator () (MemoryChunk &mc1, MemoryChunk &mc2) {
        if (mc1.get_start_add() <= mc2.get_start_add()) return true;
        else return false;
    }
};

#endif // MEMORYCHUNK_H
