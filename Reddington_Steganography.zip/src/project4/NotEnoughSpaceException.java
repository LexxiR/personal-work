package project4;
/*
 * 
 * Author: Lexxi Reddington
 * File Name: Reddington_Steganography
 * Assignment 4: Encoding and decoding secret messages inside binary files
 * Date: May 9, 2018
 *  
 */
public class NotEnoughSpaceException extends Exception {
	public NotEnoughSpaceException(int spaceNeeded, int spaceAvailable) {
		super("The amount of space needed is " + spaceNeeded + ", but the space available is " + spaceAvailable);
	}
	
	public NotEnoughSpaceException() {
		super("There is not enough space available.");
	}
}
