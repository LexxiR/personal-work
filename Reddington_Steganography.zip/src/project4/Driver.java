package project4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

/*
 * 
 * Author: Lexxi Reddington
 * File Name: Reddington_Steganography
 * Assignment 4: Encoding and decoding secret messages inside binary files
 * Date: May 9, 2018
 *  
 */
public class Driver {

	public static void main(String[] args) {
		
		//Test 1 -- secret message: "Intro 2 is such an awesome class"
//		File file2 = new File("encoded-1.wav");
//		try {
//			System.out.print(Steganography.decodeMessage(file2));
//		} catch (SecretMessageException e) {
//			e.printStackTrace();
//		}
		
		File file1 = new File("DefinitelyNotASecretMessage.wav");
		
		File outputFile = new File("myEncodedMessage.wav"); 

		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter a message: "); 
		String message = keyboard.nextLine();

		try {
			Steganography.encodeMessage(file1, outputFile, message);
			System.out.println("The decoded message is: " + Steganography.decodeMessage(outputFile));
		} catch (NotEnoughSpaceException e) {
			System.out.println(e.getMessage());
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (SecretMessageException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}