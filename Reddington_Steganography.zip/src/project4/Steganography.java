package project4;
/*
 * 
 * Author: Lexxi Reddington
 * File Name: Reddington_Steganography
 * Assignment 4: Encoding and decoding secret messages inside binary files
 * Date: May 9, 2018
 *  
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;
import java.nio.file.*;

//int = 4 bytes, char = 2 bytes
public class Steganography {
	//Method that returns an array that indicates where each character in the message should be stored
	public static int[] getDataLocations(int start, int stop, int numLocations) throws NotEnoughSpaceException{
		int spaceNeeded = numLocations*6; //Units in bytes
		int spaceAvailable = stop-start; //Units in bytes
		int spacing = (stop-start)/numLocations;
		int array[] = new int[numLocations];
		
		if (spaceNeeded <= spaceAvailable) {
			for(int i = 0; i < numLocations; ++i) {
				array[i] = start + (spacing*i);
				//array[1] has location of byte that holds char 1, array[2] has location of byte that holds char 2, etc.
			}
		} else {
			throw new NotEnoughSpaceException(spaceNeeded, spaceAvailable);
		}
		array[numLocations-1] = 0;
		return array;
	}

	//Read from RandomAccessFile -- decode secret message
	public static String decodeMessage(File inputFile) throws SecretMessageException {
		try {
			RandomAccessFile raf = new RandomAccessFile(inputFile, "rw");
			raf.seek(50);
			int length = raf.readInt(); //To get the length/numLocations
			char data[] = new char[length];
			int j = 54;
			for(int i = 0; i < length; ++i) {
				data[i] = raf.readChar(); //To get first letter in message
				j = raf.readInt();
				raf.seek(j); //To get location (byte) of next char
			}
			String message = new String(data);
			return message;
		} catch (IOException e) {
			throw new SecretMessageException();
		}
	}

	//Write to RandomAccessFile -- encode secret message
	public static void encodeMessage(File inputFile, File outputFile, String message) throws Exception {
		Files.copy(inputFile.toPath(), outputFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
		RandomAccessFile raf = new RandomAccessFile(outputFile, "rw");
		try {
			int messageLength = message.length();
			raf.seek(50);
			raf.writeInt(messageLength);
			int array[] = getDataLocations(54, (int)inputFile.length(), messageLength);
			for(int i = 0; i < messageLength; ++i) {
				raf.seek(array[i]);
				raf.writeChar(message.charAt(i));
				raf.writeInt(array[i+1]);
			}
		} catch (Exception e) {
			return;
		}
	}
}