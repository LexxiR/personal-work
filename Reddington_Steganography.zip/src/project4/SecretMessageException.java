package project4;
/*
 * 
 * Author: Lexxi Reddington
 * File Name: Reddington_Steganography
 * Assignment 4: Encoding and decoding secret messages inside binary files
 * Date: May 9, 2018
 *  
 */
public class SecretMessageException extends Exception{
	public SecretMessageException(String message) {
		super(message);
	}
	
	public SecretMessageException() {
		super("There was an error decoding the message.");	
	}	
}