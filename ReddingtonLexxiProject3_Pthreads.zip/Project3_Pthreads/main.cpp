/*
 * Lexxi Reddington 
 * Project 3: Perfect Numbers
 * VERSION: Pthreads (POSIX threads) 
 * Operating Systems, Spring 2020
 */

#include <iostream>
#include <array>
#include <math.h>
#include <pthread.h>

// Shared variables
uint64_t num_factors{0};
std::array<uint64_t, 100> shared_buffer;
uint64_t buffer_index{0};

// Mutex to protect shared data (critical region)
pthread_mutex_t mutex;

// Function to determine if a number is a factor of another
void *find_factors(void *arg);

// Struct to hold thread arguments
struct thread_args {
    uint64_t number_being_checked;
    uint64_t start_value;
    uint64_t ending_value;
};

int main(int argc, char* argv[]) {
    // User input
	std::cout << "Enter number: \n";
    uint64_t number;
    std::cin >> number;
    std::cout << "Number of threads: \n";
    uint64_t num_threads;
    std::cin >> num_threads;
    
    // Thread set up to partition number
    // Note: Only numbers 1 through number / 2 need to be checked for factors
    pthread_mutex_init(&mutex, NULL);
    pthread_t tid[num_threads];   
    thread_args args[num_threads];
    
    uint64_t set_size = ceil((static_cast<double>(number) / 2) / num_threads);
    
    for (uint64_t i = 0; i < num_threads; ++i) {
        uint64_t start_index = 1 + (set_size * i);
        uint64_t end_index = set_size + (set_size * i);
        if (end_index > number / 2) {
            end_index = number / 2;
        }
        args[i] = {number, start_index, end_index};
    }
    
    // Create threads and have them find the factors
    for (uint64_t i = 0; i < num_threads; ++i) {
        uint64_t status = pthread_create(&tid[i], NULL, find_factors, &args[i]);
        if (status != 0) {
            std::cerr << "Unable to create thread" << std::endl;
        }
    }
    
    // Join threads
    for (uint64_t i = 0; i < num_threads; i++) {
        pthread_join(tid[i], NULL);
    }
    
    // Print out each factor
    std::cout << "\nNumber of factors is: " << num_factors << "\n";
    uint64_t sum = 0;
    
    for (uint64_t factor : shared_buffer) {
        sum += factor;
        if(factor == 0) break; 
        std::cout << factor << "\n";
    }
    
    // Determine if the number is perfect
    if (sum == number) {
        std::cout << "\n" << number << " is a perfect number!\n";
    } else {
        std::cout << "\n" << number << " is not a perfect number.\n";
    }
	return 0;
}

// Start routine
void *find_factors(void *arg) {
    // Grab values from the struct
    thread_args args = *static_cast<thread_args*> (arg);
    uint64_t number = args.number_being_checked;
    uint64_t start_index = args.start_value;
    uint64_t end_index = args.ending_value;
    
    // Determine the factors
    for (uint64_t i = start_index; i <= end_index; ++i) {
        if (number % i == 0) { 
            // Write factor to the shared buffer
            pthread_mutex_lock(&mutex);
            shared_buffer[buffer_index] = i;
            ++buffer_index;
            ++num_factors;
            pthread_mutex_unlock(&mutex);
        } 
    } 
    pthread_exit(0);
}
