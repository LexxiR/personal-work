/*
 * Lexxi Reddington 
 * Project 6: Deadlock Detection
 * Operating Systems, Spring 2020
 */
 
#include "DeadlockDetector.h"
#include <iostream>

DeadlockDetector::DeadlockDetector(std::string input_file) {
    // Open input file
    std::ifstream in(input_file);
    if (!in.is_open()) {
        std::cerr << "Error: Couldn't open file." << std::endl;
    } else {
        // Read the input file
        std::string line;
        while (std::getline(in, line)) {
            file.push_back(line);
        }
        // First line - Number of Processes and Resource Types
        std::istringstream ss(file[0]);
        ss >> num_processes;
        ss >> num_resource_types;
        
        // Second line - Vector E
        std::istringstream ssvec(file[1]);
        for (int i = 0; i < num_resource_types; ++i) {
            int value;
            ssvec >> value;
            vector_E.push_back(value);
        }
        
        // Next chunk of lines - Matrix C
        for (int i = 2; i < 2 + num_processes; ++i) {
            std::istringstream ss(file[i]);
            std::vector<int> temp;
            for (int j = 0; j < num_resource_types; ++j) {
                int value;
                ss >> value;
                temp.push_back(value);
            }
            allocation_matrix.push_back(temp);
        }
        
        // Last chunk of lines - Matrix R
        for (int i = 2 + num_processes; i < 2 + num_processes + num_processes; ++i) {
            std::istringstream ss(file[i]);
            std::vector<int> temp;
            for (int j = 0; j < num_resource_types; ++j) {
                int value;
                ss >> value;
                temp.push_back(value);
            }
            request_matrix.push_back(temp);
        }
        in.close();
    }
}

DeadlockDetector::~DeadlockDetector() {}

void DeadlockDetector::run() {
    // Initial console output
    print();
    set_vector_A();
    print_vector_A();
    
    std::vector<bool> marked_processes(num_processes);
    int mark_count;
    
    // Detect deadlocks
    do {
        mark_count = 0;
        int i = 0;
        for (; i < num_processes; ++i) {
            // Look for an unmarked process
            if (!marked_processes[i]) {
                // For which the ith row of R is less than or equal to A
                if (compare_vectors(request_matrix[i], vector_A)) {
                    // Add the ith row of C to A
                    for (int j = 0; j < num_resource_types; ++j) {
                        vector_A[j] += allocation_matrix[i][j];
                    }
                    // Mark the process
                    marked_processes[i] = true;
                    ++mark_count;
                    std::cout << "Process " << i << " marked\n";
                    // See the updated Vector A
                    print_vector_A();
                    // Start over again
                    i = 0;
                }
            }
        }
    } while (mark_count != 0);
    
    // More console output
    std::vector<int> deadlocked;
    for (int i = 0; i < num_processes; ++i) {
        if (!marked_processes[i]) deadlocked.push_back(i);
    }
    if (deadlocked.size() == 0) std::cout << "System is NOT deadlocked\n";
    else {
        std::cout << "System is deadlocked\n";
        std::cout << "Deadlocked processes: ";
        for (auto val : deadlocked) std::cout << val << " ";
    }
    std::cout << "\n";
}

// Helper function to print the vector and matrix values
void DeadlockDetector::print() {
    std::cout << "Initial Values: \n";
    std::cout << "Number of processes: " << num_processes << "\n";
    std::cout << "Number of resource types: " << num_resource_types << "\n";
    std::cout << "Existing Resource Vector\n";
    for (int i : vector_E) {
        std::cout << i << " ";
    }
    std::cout << "\nCurrent Allocation Matrix\n";
    for (int i = 0; i < num_processes; ++i) {
        for (int j = 0; j < num_resource_types; ++j) {
            std::cout << allocation_matrix[i][j] << " ";
        }
        std::cout << "\n";
    }
    std::cout << "Request Matrix\n";
    for (int i = 0; i < num_processes; ++i) {
        for (int j = 0; j < num_resource_types; ++j) {
            std::cout << request_matrix[i][j] << " ";
        }
        std::cout << "\n";
    }
}

// Helper function to calculate the Available Resource Vector 
void DeadlockDetector::set_vector_A() {
    // Sum up each column in the Allocation Matrix
    std::vector<int> vector_sums(num_resource_types);
    for (int i = 0; i < num_processes; ++i) {
        for (int j = 0; j < num_resource_types; ++j) {
            int sum = vector_sums[j];
            sum += allocation_matrix[i][j];
            vector_sums[j] = sum;
        }
    }
    // Vector A = Vector E - Sum of each column in the Allocation Matrix
    for (int i = 0; i < num_resource_types; ++i) {
        int val = vector_E[i] - vector_sums[i];
        vector_A.push_back(val);
    }
}

// Helper function to print the contents of Vector A
void DeadlockDetector::print_vector_A() {
    std::cout << "Available Resource Vector\n";
    for (auto val : vector_A) {
        std::cout << val << " ";
    }
    std::cout << "\n\n";
}

// Helper function to compare two vectors' values
bool DeadlockDetector::compare_vectors(std::vector<int> R, std::vector<int> A) {
    if (R.size() != A.size()) return false;
    for (uint i = 0; i < R.size(); ++i) {
        if (R[i] > A[i]) return false;
    }
    return true;
}
