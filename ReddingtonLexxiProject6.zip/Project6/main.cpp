/*
 * Lexxi Reddington 
 * Project 6: Deadlock Detection
 * Operating Systems, Spring 2020
 */

#include "DeadlockDetector.h" 
#include <iostream>

int main(int argc, char* argv[]) {
	// Check the number of command line arguments given
    if (argc != 2) {
        // Tell the user how to run the program
        std::cerr << "Usage: " << argv[0] << " <input filename>" << std::endl;
        return 1;
    }
    
    // Start the deadlock detector!
    DeadlockDetector dd(argv[1]);
    dd.run();
    
	return 0;
}
