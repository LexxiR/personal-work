/*
 * Lexxi Reddington 
 * Project 6: Deadlock Detection
 * Operating Systems, Spring 2020
 */
 
#ifndef DEADLOCKDETECTOR_H
#define DEADLOCKDETECTOR_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

class DeadlockDetector {
private:
    // Member variables
    std::vector<std::string> file;
    int num_processes;
    int num_resource_types;
    std::vector<int> vector_E;
    std::vector<int> vector_A;
    std::vector<std::vector<int>> allocation_matrix;
    std::vector<std::vector<int>> request_matrix;
    // Helper functions
    void print();
    void set_vector_A();
    void print_vector_A();
    bool compare_vectors(std::vector<int> R, std::vector<int> A);
public:
    DeadlockDetector(std::string input_file);
    ~DeadlockDetector();
    void run();
};

#endif // DEADLOCKDETECTOR_H
